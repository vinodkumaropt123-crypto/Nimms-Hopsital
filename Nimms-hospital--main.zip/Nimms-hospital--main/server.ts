import express from 'express';
import path from 'path';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { db, Appointment, Order, User } from './server/db.js';

const app = express();
const PORT = 3000;

app.use(express.json());

// Set up a simple cache/map to hold active session tokens for logged-in sessions inside the container.
// This matches standard token session verification.
const ACTIVE_SESSIONS = new Map<string, { email: string; role: string; expiresAt: number }>();

// Security Helper: Hash strings with SHA-256
function sha256(text: string): string {
  return crypto.createHash('sha256').update(text).digest('hex');
}

// Security Middleware: Verify admin or staff credentials
const authenticateToken = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const authHeader = req.headers['authorization'];
  if (!authHeader) {
    res.status(401).json({ error: 'Access denied. Authorization header is missing.' });
    return;
  }

  const token = authHeader.replace(/^Bearer\s+/, '');
  const session = ACTIVE_SESSIONS.get(token);

  if (!session) {
    res.status(401).json({ error: 'Session has ended or is invalid. Please sign in again.' });
    return;
  }

  if (Date.now() > session.expiresAt) {
    ACTIVE_SESSIONS.delete(token);
    res.status(401).json({ error: 'Session expired. Please log in again.' });
    return;
  }

  // Inject session details into request
  (req as any).user = session;
  next();
};

// =====================================================================
// AUTHENTICATION API ENDPOINTS
// =====================================================================

app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
       res.status(400).json({ error: 'Both email and password are required credentials.' });
       return;
    }

    const matchedUser = db.getUsers().find(u => u.email.toLowerCase() === email.toLowerCase());
    
    if (!matchedUser) {
       res.status(401).json({ error: 'Incorrect email address or password. Access denied.' });
       return;
    }

    if (matchedUser.status === 'Suspended') {
       res.status(403).json({ error: 'This user account is suspended. Reach support coordinates.' });
       return;
    }

    const inputHash = sha256(password);
    if (inputHash !== matchedUser.passwordHash) {
       res.status(401).json({ error: 'Incorrect email address or password. Access denied.' });
       return;
    }

    // Generate secure session token
    const token = crypto.randomBytes(32).toString('hex');
    const SIX_HOURS = 6 * 60 * 60 * 1000;
    
    ACTIVE_SESSIONS.set(token, {
      email: matchedUser.email,
      role: matchedUser.role,
      expiresAt: Date.now() + SIX_HOURS
    });

     res.status(200).json({
      message: 'Authentication successful',
      token,
      profile: {
        id: matchedUser.id,
        name: matchedUser.name,
        email: matchedUser.email,
        phone: matchedUser.phone,
        role: matchedUser.role
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: 'Internal Auth execution failed: ' + error.message });
  }
});

app.post('/api/auth/logout', (req, res) => {
  const authHeader = req.headers['authorization'];
  if (authHeader) {
    const token = authHeader.replace(/^Bearer\s+/, '');
    ACTIVE_SESSIONS.delete(token);
  }
  res.status(200).json({ status: 'ok', message: 'Logged out successfully' });
});

// =====================================================================
// APPOINTMENTS CRUD ENDPOINTS
// =====================================================================

// GET All - Protected
app.get('/api/appointments', authenticateToken, (req, res) => {
  try {
    res.status(200).json(db.getAppointments());
  } catch (error: any) {
    res.status(500).json({ error: 'Failed to retrieve records: ' + error.message });
  }
});

// POST Create (Public - can be used from Front-end form or Admin)
app.post('/api/appointments', (req, res) => {
  try {
    const { name, phone, department, doctor, date, timeSlot, notes } = req.body;

    // Secure Input Validations
    if (!name || name.trim().length < 2) {
       res.status(400).json({ error: 'Full Name must be at least 2 characters.' });
       return;
    }
    if (!phone || phone.trim().length < 8) {
       res.status(400).json({ error: 'Please enter a valid primary phone contact number.' });
       return;
    }
    if (!department || !doctor) {
       res.status(400).json({ error: 'Both department specialty and doctor choice are required.' });
       return;
    }
    if (!date || isNaN(Date.parse(date))) {
       res.status(400).json({ error: 'A valid preferred calendar date is required.' });
       return;
    }
    if (!timeSlot) {
       res.status(400).json({ error: 'Preferred consulting hour slot selection is required.' });
       return;
    }

    const appt = db.addAppointment({
      name: name.trim(),
      phone: phone.trim(),
      department,
      doctor,
      date,
      timeSlot,
      notes: notes ? notes.trim() : '',
      status: 'Pending'
    });

    res.status(201).json({
      message: 'Appointment successfully scheduled and queued.',
      appointment: appt
    });
  } catch (error: any) {
    res.status(500).json({ error: 'Failed scheduling appointment: ' + error.message });
  }
});

// PUT Update status or details - Protected
app.put('/api/appointments/:id', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const validatedUpdates: Partial<Omit<Appointment, 'id' | 'createdAt'>> = {};
    
    if (updates.name !== undefined) validatedUpdates.name = String(updates.name).trim();
    if (updates.phone !== undefined) validatedUpdates.phone = String(updates.phone).trim();
    if (updates.department !== undefined) validatedUpdates.department = String(updates.department);
    if (updates.doctor !== undefined) validatedUpdates.doctor = String(updates.doctor);
    if (updates.date !== undefined) validatedUpdates.date = String(updates.date);
    if (updates.timeSlot !== undefined) validatedUpdates.timeSlot = String(updates.timeSlot);
    if (updates.notes !== undefined) validatedUpdates.notes = String(updates.notes).trim();
    if (updates.status !== undefined) {
      if (!['Pending', 'Confirmed', 'Completed', 'Cancelled'].includes(updates.status)) {
         res.status(400).json({ error: 'Status must be Pending, Confirmed, Completed, or Cancelled.' });
         return;
      }
      validatedUpdates.status = updates.status as any;
    }

    const updated = db.updateAppointment(id, validatedUpdates);
    if (!updated) {
       res.status(404).json({ error: `Appointment session with key ${id} could not be uncovered.` });
       return;
    }

    res.status(200).json({
      message: 'Appointment modified and saved successfully.',
      appointment: updated
    });
  } catch (error: any) {
    res.status(500).json({ error: 'Failed updating appointment: ' + error.message });
  }
});

// DELETE Delete appointment - Protected
app.delete('/api/appointments/:id', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;
    const matchesUser = db.deleteAppointment(id);
    if (!matchesUser) {
       res.status(404).json({ error: `Appointment key ${id} was not present.` });
       return;
    }
    res.status(200).json({ message: `Successfully expunged appointment ${id} logs from the system database.` });
  } catch (error: any) {
    res.status(500).json({ error: 'Failed purging record: ' + error.message });
  }
});

// =====================================================================
// ORDERS CRUD ENDPOINTS
// =====================================================================

// GET All Orders - Protected
app.get('/api/orders', authenticateToken, (req, res) => {
  try {
    res.status(200).json(db.getOrders());
  } catch (error: any) {
    res.status(500).json({ error: 'Failed to match diagnostic billing tickets: ' + error.message });
  }
});

// POST Create Order - Protected (or public for checkouts)
app.post('/api/orders', authenticateToken, (req, res) => {
  try {
    const { patientName, email, phone, packageName, amount, status, paymentMethod, date } = req.body;

    if (!patientName || !email || !packageName || amount === undefined || !paymentMethod) {
       res.status(400).json({ error: 'Patient details, treatment bundle itemized specifications, rate cost, and payment methods are required structures.' });
       return;
    }

    const order = db.addOrder({
      patientName: patientName.trim(),
      email: email.trim(),
      phone: phone ? phone.trim() : '+91 XXXXX XXXXX',
      packageName: packageName.trim(),
      amount: Number(amount),
      status: status || 'Pending',
      paymentMethod,
      date: date || new Date().toISOString().split('T')[0]
    });

    res.status(201).json({
      message: 'Invoice order registered.',
      order
    });
  } catch (error: any) {
    res.status(500).json({ error: 'Failed executing purchase log: ' + error.message });
  }
});

// PUT Update Order - Protected
app.put('/api/orders/:id', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const validatedUpdates: Partial<Omit<Order, 'id' | 'createdAt'>> = {};

    if (updates.patientName !== undefined) validatedUpdates.patientName = String(updates.patientName).trim();
    if (updates.email !== undefined) validatedUpdates.email = String(updates.email).trim();
    if (updates.phone !== undefined) validatedUpdates.phone = String(updates.phone).trim();
    if (updates.packageName !== undefined) validatedUpdates.packageName = String(updates.packageName).trim();
    if (updates.amount !== undefined) validatedUpdates.amount = Number(updates.amount);
    if (updates.paymentMethod !== undefined) validatedUpdates.paymentMethod = String(updates.paymentMethod);
    if (updates.status !== undefined) {
      if (!['Pending', 'Paid', 'Shipped', 'Cancelled'].includes(updates.status)) {
         res.status(400).json({ error: 'Status category must equal Pending, Paid, Shipped, or Cancelled.' });
         return;
      }
      validatedUpdates.status = updates.status as any;
    }

    const updated = db.updateOrder(id, validatedUpdates);
    if (!updated) {
       res.status(404).json({ error: `Medical order invoice ID ${id} cannot be tracked.` });
       return;
    }

    res.status(200).json({
      message: 'Treatment package order entry updated successfully.',
      order: updated
    });
  } catch (error: any) {
    res.status(500).json({ error: 'Failed modifying invoice ticket: ' + error.message });
  }
});

// DELETE Order - Protected
app.delete('/api/orders/:id', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;
    const removed = db.deleteOrder(id);
    if (!removed) {
       res.status(404).json({ error: `Diagnostic order bill ticket ${id} is already absent.` });
       return;
    }
    res.status(200).json({ message: `Invoice bill order log with index ${id} successfully removed.` });
  } catch (error: any) {
    res.status(500).json({ error: 'Failed clearing invoice entry: ' + error.message });
  }
});

// =====================================================================
// USERS DATA CRUD ENDPOINTS
// =====================================================================

// GET All Users - Protected
app.get('/api/users', authenticateToken, (req, res) => {
  try {
    // Return all users (omit password hashes from standard response for maximum safety)
    const secureUsersList = db.getUsers().map(({ passwordHash, ...rest }) => rest);
    res.status(200).json(secureUsersList);
  } catch (error: any) {
    res.status(500).json({ error: 'Failed accessing credential lists: ' + error.message });
  }
});

// POST Create User - Protected
app.post('/api/users', authenticateToken, (req, res) => {
  try {
    const { name, email, phone, role, status, password } = req.body;

    if (!name || !email || !password || !role) {
       res.status(400).json({ error: 'User display name, valid email, active system role, and access password are required structures.' });
       return;
    }

    const exists = db.getUsers().some(u => u.email.toLowerCase() === email.toLowerCase().trim());
    if (exists) {
       res.status(400).json({ error: 'A staff member or client user with that email already exists.' });
       return;
    }

    const created = db.addUser({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone ? phone.trim() : '+91 XXXXX XXXXX',
      role: role || 'Patient',
      status: status || 'Active',
      passwordHash: sha256(password)
    });

    const { passwordHash, ...safeUser } = created;
    res.status(201).json({
      message: 'Account created with success.',
      user: safeUser
    });
  } catch (error: any) {
    res.status(500).json({ error: 'Failed to create user model: ' + error.message });
  }
});

// PUT Update User - Protected
app.put('/api/users/:id', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const validatedUpdates: Partial<Omit<User, 'id' | 'createdAt'>> = {};

    if (updates.name !== undefined) validatedUpdates.name = String(updates.name).trim();
    if (updates.email !== undefined) validatedUpdates.email = String(updates.email).trim().toLowerCase();
    if (updates.phone !== undefined) validatedUpdates.phone = String(updates.phone).trim();
    if (updates.role !== undefined) {
      if (!['Patient', 'Doctor', 'Admin'].includes(updates.role)) {
         res.status(400).json({ error: 'Role choice must specify Patient, Doctor, or Admin.' });
         return;
      }
      validatedUpdates.role = updates.role as any;
    }
    if (updates.status !== undefined) {
      if (!['Active', 'Suspended'].includes(updates.status)) {
         res.status(400).json({ error: 'User index status must say Active or Suspended.' });
         return;
      }
      validatedUpdates.status = updates.status as any;
    }
    if (updates.password && updates.password.trim() !== '') {
      validatedUpdates.passwordHash = sha256(updates.password);
    }

    const updated = db.updateUser(id, validatedUpdates);
    if (!updated) {
       res.status(404).json({ error: `User profile credentials with index ${id} could not be uncovered.` });
       return;
    }

    const { passwordHash, ...safeUser } = updated;
    res.status(200).json({
      message: 'Account record updated successfully.',
      user: safeUser
    });
  } catch (error: any) {
    res.status(500).json({ error: 'Failed modifying user coordinates: ' + error.message });
  }
});

// DELETE User - Protected
app.delete('/api/users/:id', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;

    // Direct protection: Prevent deleting the superadmin session in context
    if (id === 'user-admin') {
       res.status(403).json({ error: 'Deleting the core master administrator directory profile is restricted.' });
       return;
    }

    const removed = db.deleteUser(id);
    if (!removed) {
       res.status(404).json({ error: `User ID ${id} is not present inside database registers.` });
       return;
    }

    res.status(200).json({ message: `Successfully expunged user identifier ${id} coordinates from active registers.` });
  } catch (error: any) {
    res.status(500).json({ error: 'Failed expunging user log: ' + error.message });
  }
});


// =====================================================================
// SERVE FRONTEND (Vite / Prod)
// =====================================================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SYS] Full-stack Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
