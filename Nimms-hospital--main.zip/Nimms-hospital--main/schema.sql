-- =====================================================================
-- NIMMS HOSPITAL DATABASE SCHEMA FOR DEPLOYMENT ON HOSTINGER (MySQL/MariaDB)
-- =====================================================================
-- Run this script in your Hostinger PHPMyAdmin, MySQL console or Database Hub.

CREATE DATABASE IF NOT EXISTS nimms_hospital_db;
USE nimms_hospital_db;

-- 1. Patients and Admin Accounts Table
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `phone` VARCHAR(25) NOT NULL,
  `role` ENUM('Patient', 'Doctor', 'Admin') NOT NULL DEFAULT 'Patient',
  `status` ENUM('Active', 'Suspended') NOT NULL DEFAULT 'Active',
  `passwordHash` VARCHAR(255) NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Clinic Appointments Table
CREATE TABLE IF NOT EXISTS `appointments` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(25) NOT NULL,
  `department` VARCHAR(50) NOT NULL,
  `doctor` VARCHAR(50) NOT NULL,
  `date` DATE NOT NULL,
  `timeSlot` VARCHAR(100) NOT NULL,
  `notes` TEXT NULL,
  `status` ENUM('Pending', 'Confirmed', 'Completed', 'Cancelled') NOT NULL DEFAULT 'Pending',
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Invoices, Prescriptions and Orders Table
CREATE TABLE IF NOT EXISTS `orders` (
  `id` VARCHAR(50) NOT NULL,
  `patientName` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(25) NOT NULL,
  `packageName` VARCHAR(150) NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `status` ENUM('Pending', 'Paid', 'Shipped', 'Cancelled') NOT NULL DEFAULT 'Pending',
  `paymentMethod` VARCHAR(100) NOT NULL,
  `date` DATE NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- =====================================================================
-- INITIAL DISPATCH SEED RECORDS
-- =====================================================================

-- Insert Default Admin (Password: nimmsadmin123)
-- SHA-256 for 'nimmsadmin123' = f45447471f005d5bc418a09f3e4eeeb79f41deba94689cbfaee1da8a67de0c3c
INSERT INTO `users` (`id`, `name`, `email`, `phone`, `role`, `status`, `passwordHash`, `createdAt`)
VALUES (
  'user-admin', 
  'Admin Coordinator', 
  'admin@nimms.com', 
  '+91 11 4987 6543', 
  'Admin', 
  'Active', 
  'f45447471f005d5bc418a09f3e4eeeb79f41deba94689cbfaee1da8a67de0c3c', 
  NOW()
) ON DUPLICATE KEY UPDATE `id`=`id`;

-- Insert Default Doctor
INSERT INTO `users` (`id`, `name`, `email`, `phone`, `role`, `status`, `passwordHash`, `createdAt`)
VALUES (
  'user-doctor1', 
  'Dr. Alok Nath', 
  'alok.nath@nimms.com', 
  '+91 98100 12345', 
  'Doctor', 
  'Active', 
  '5e883f3b11c21184c7e6fbdb2fc85145b2555029e28dc191fc13876e409d57a2', -- 'doctor123'
  NOW()
) ON DUPLICATE KEY UPDATE `id`=`id`;

-- Insert Sample Appointments
INSERT INTO `appointments` (`id`, `name`, `phone`, `department`, `doctor`, `date`, `timeSlot`, `notes`, `status`, `createdAt`)
VALUES 
('NIMMS-485920', 'Anand Gupta', '+91 98111 22233', 'general-medicine', 'doc-alok-nath', '2026-06-25', '10:00 AM - 11:00 AM', 'Regular full-body health checkup and consultation.', 'Confirmed', NOW()),
('NIMMS-849204', 'Priyanka Sharma', '+91 98222 33344', 'pediatrics', 'doc-meera-reddy', '2026-06-26', '11:00 AM - 12:00 PM', 'Inoculation appointment for baby boy.', 'Pending', NOW()),
('NIMMS-128490', 'Rajesh Kumar', '+91 98333 44455', 'orthopedics', 'doc-sanjay-sharma', '2026-06-24', '03:00 PM - 04:00 PM', 'Posterior ankle bone scan verification and diagnostic review.', 'Completed', NOW())
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Insert Sample Orders
INSERT INTO `orders` (`id`, `patientName`, `email`, `phone`, `packageName`, `amount`, `status`, `paymentMethod`, `date`, `createdAt`)
VALUES 
('ORD-948201', 'Anand Gupta', 'anand.gupta@gmail.com', '+91 98111 22233', 'Comprehensive Full-Body Checkup Package', 5499.00, 'Paid', 'Credit Card (Razorpay)', '2026-06-15', NOW()),
('ORD-302910', 'Devender Rawat', 'dev.rawat@yahoo.com', '+91 99100 99887', 'Advanced Cardiac Wellness Assays Block', 8999.00, 'Pending', 'UPI (GPay)', '2026-06-18', NOW())
ON DUPLICATE KEY UPDATE `id`=`id`;
