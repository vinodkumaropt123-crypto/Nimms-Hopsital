import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// Types matching the required models
export interface Appointment {
  id: string;
  name: string;
  phone: string;
  department: string;
  doctor: string;
  date: string;
  timeSlot: string;
  notes?: string;
  status: 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled';
  createdAt: string;
}

export interface Order {
  id: string;
  patientName: string;
  email: string;
  phone: string;
  packageName: string;
  amount: number;
  status: 'Pending' | 'Paid' | 'Shipped' | 'Cancelled';
  paymentMethod: string;
  date: string;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'Patient' | 'Doctor' | 'Admin';
  status: 'Active' | 'Suspended';
  passwordHash: string; // SHA-256
  createdAt: string;
}

const DATABASE_DIR = path.join(process.cwd(), 'data');
const DATABASE_FILE = path.join(DATABASE_DIR, 'db.json');

// Default Seed Data
const DEFAULT_USERS: User[] = [
  {
    id: 'user-admin',
    name: 'Admin Coordinator',
    email: 'admin@nimms.com',
    phone: '+91 11 4987 6543',
    role: 'Admin',
    status: 'Active',
    // SHA-256 for 'nimmsadmin123'
    passwordHash: 'f45447471f005d5bc418a09f3e4eeeb79f41deba94689cbfaee1da8a67de0c3c',
    createdAt: new Date('2026-01-10T10:00:00Z').toISOString()
  },
  {
    id: 'user-doctor1',
    name: 'Dr. Alok Nath',
    email: 'alok.nath@nimms.com',
    phone: '+91 98100 12345',
    role: 'Doctor',
    status: 'Active',
    passwordHash: crypto.createHash('sha256').update('doctor123').digest('hex'),
    createdAt: new Date('2026-01-15T09:00:00Z').toISOString()
  },
  {
    id: 'user-patient1',
    name: 'Anand Gupta',
    email: 'anand.gupta@gmail.com',
    phone: '+91 98111 22233',
    role: 'Patient',
    status: 'Active',
    passwordHash: crypto.createHash('sha256').update('patient123').digest('hex'),
    createdAt: new Date('2026-02-20T14:30:00Z').toISOString()
  }
];

const DEFAULT_APPOINTMENTS: Appointment[] = [
  {
    id: 'NIMMS-485920',
    name: 'Anand Gupta',
    phone: '+91 98111 22233',
    department: 'general-medicine',
    doctor: 'doc-alok-nath',
    date: '2026-06-25',
    timeSlot: '10:00 AM - 11:00 AM',
    notes: 'Regular full-body health checkup and consultation.',
    status: 'Confirmed',
    createdAt: new Date('2026-06-15T11:20:00Z').toISOString()
  },
  {
    id: 'NIMMS-849204',
    name: 'Priyanka Sharma',
    phone: '+91 98222 33344',
    department: 'pediatrics',
    doctor: 'doc-meera-reddy',
    date: '2026-06-26',
    timeSlot: '11:00 AM - 12:00 PM',
    notes: 'Inoculation appointment for baby boy.',
    status: 'Pending',
    createdAt: new Date('2026-06-17T09:45:00Z').toISOString()
  },
  {
    id: 'NIMMS-128490',
    name: 'Rajesh Kumar',
    phone: '+91 98333 44455',
    department: 'orthopedics',
    doctor: 'doc-sanjay-sharma',
    date: '2026-06-24',
    timeSlot: '03:00 PM - 04:00 PM',
    notes: 'Posterior ankle bone scan verification and diagnostic review.',
    status: 'Completed',
    createdAt: new Date('2026-06-12T15:10:00Z').toISOString()
  },
  {
    id: 'NIMMS-783910',
    name: 'Asha Singh',
    phone: '+91 98444 55566',
    department: 'gynecology',
    doctor: 'doc-ananya-sen',
    date: '2026-06-28',
    timeSlot: '02:00 PM - 03:00 PM',
    notes: 'Routine maternity care scanning.',
    status: 'Confirmed',
    createdAt: new Date('2026-06-18T08:00:00Z').toISOString()
  }
];

const DEFAULT_ORDERS: Order[] = [
  {
    id: 'ORD-948201',
    patientName: 'Anand Gupta',
    email: 'anand.gupta@gmail.com',
    phone: '+91 98111 22233',
    packageName: 'Comprehensive Full-Body Checkup Package',
    amount: 5499,
    status: 'Paid',
    paymentMethod: 'Credit Card (Razorpay)',
    date: '2026-06-15',
    createdAt: new Date('2026-06-15T11:25:00Z').toISOString()
  },
  {
    id: 'ORD-302910',
    patientName: 'Devender Rawat',
    email: 'dev.rawat@yahoo.com',
    phone: '+91 99100 99887',
    packageName: 'Advanced Cardiac Wellness Assays Block',
    amount: 8999,
    status: 'Pending',
    paymentMethod: 'UPI (GPay)',
    date: '2026-06-18',
    createdAt: new Date('2026-06-18T07:12:00Z').toISOString()
  },
  {
    id: 'ORD-109284',
    patientName: 'Sunita Mehra',
    email: 'sunita.mehra@hotmail.com',
    phone: '+91 98711 65432',
    packageName: 'Pediatric Vaccine Core Immunization Kit',
    amount: 3200,
    status: 'Paid',
    paymentMethod: 'Net Banking (HDFC)',
    date: '2026-06-16',
    createdAt: new Date('2026-06-16T14:22:00Z').toISOString()
  }
];

interface DatabaseSchema {
  users: User[];
  appointments: Appointment[];
  orders: Order[];
}

export class JsonDb {
  private schema: DatabaseSchema = { users: [], appointments: [], orders: [] };

  constructor() {
    this.initDatabase();
  }

  private initDatabase() {
    if (!fs.existsSync(DATABASE_DIR)) {
      fs.mkdirSync(DATABASE_DIR, { recursive: true });
    }

    if (!fs.existsSync(DATABASE_FILE)) {
      this.schema = {
        users: DEFAULT_USERS,
        appointments: DEFAULT_APPOINTMENTS,
        orders: DEFAULT_ORDERS
      };
      this.save();
    } else {
      try {
        const raw = fs.readFileSync(DATABASE_FILE, 'utf8');
        this.schema = JSON.parse(raw);
        // Fallbacks in case format shifts
        if (!this.schema.users) this.schema.users = DEFAULT_USERS;
        if (!this.schema.appointments) this.schema.appointments = DEFAULT_APPOINTMENTS;
        if (!this.schema.orders) this.schema.orders = DEFAULT_ORDERS;
      } catch (err) {
        console.error("Failed to read database file. Re-initializing...", err);
        this.schema = {
          users: DEFAULT_USERS,
          appointments: DEFAULT_APPOINTMENTS,
          orders: DEFAULT_ORDERS
        };
        this.save();
      }
    }
  }

  private save() {
    try {
      fs.writeFileSync(DATABASE_FILE, JSON.stringify(this.schema, null, 2), 'utf8');
    } catch (err) {
      console.error("Failed to write to database file:", err);
    }
  }

  // USERS OPERATIONS
  public getUsers(): User[] {
    return this.schema.users;
  }

  public addUser(user: Omit<User, 'id' | 'createdAt'>): User {
    const newUser: User = {
      ...user,
      id: 'USR-' + Math.floor(100000 + Math.random() * 900000),
      createdAt: new Date().toISOString()
    };
    this.schema.users.push(newUser);
    this.save();
    return newUser;
  }

  public updateUser(id: string, updates: Partial<Omit<User, 'id' | 'createdAt'>>): User | null {
    const idx = this.schema.users.findIndex(u => u.id === id);
    if (idx === -1) return null;
    
    this.schema.users[idx] = {
      ...this.schema.users[idx],
      ...updates
    };
    this.save();
    return this.schema.users[idx];
  }

  public deleteUser(id: string): boolean {
    const initialLen = this.schema.users.length;
    this.schema.users = this.schema.users.filter(u => u.id !== id);
    if (this.schema.users.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // APPOINTMENTS OPERATIONS
  public getAppointments(): Appointment[] {
    return this.schema.appointments;
  }

  public addAppointment(appt: Omit<Appointment, 'id' | 'createdAt'> & { id?: string }): Appointment {
    const newAppt: Appointment = {
      ...appt,
      id: appt.id || 'NIMMS-' + Math.floor(100000 + Math.random() * 900000),
      createdAt: new Date().toISOString()
    };
    this.schema.appointments.push(newAppt);
    this.save();
    return newAppt;
  }

  public updateAppointment(id: string, updates: Partial<Omit<Appointment, 'id' | 'createdAt'>>): Appointment | null {
    const idx = this.schema.appointments.findIndex(a => a.id === id);
    if (idx === -1) return null;

    this.schema.appointments[idx] = {
      ...this.schema.appointments[idx],
      ...updates
    };
    this.save();
    return this.schema.appointments[idx];
  }

  public deleteAppointment(id: string): boolean {
    const initialLen = this.schema.appointments.length;
    this.schema.appointments = this.schema.appointments.filter(a => a.id !== id);
    if (this.schema.appointments.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // ORDERS OPERATIONS
  public getOrders(): Order[] {
    return this.schema.orders;
  }

  public addOrder(order: Omit<Order, 'id' | 'createdAt'>): Order {
    const newOrder: Order = {
      ...order,
      id: 'ORD-' + Math.floor(100000 + Math.random() * 900000),
      createdAt: new Date().toISOString()
    };
    this.schema.orders.push(newOrder);
    this.save();
    return newOrder;
  }

  public updateOrder(id: string, updates: Partial<Omit<Order, 'id' | 'createdAt'>>): Order | null {
    const idx = this.schema.orders.findIndex(o => o.id === id);
    if (idx === -1) return null;

    this.schema.orders[idx] = {
      ...this.schema.orders[idx],
      ...updates
    };
    this.save();
    return this.schema.orders[idx];
  }

  public deleteOrder(id: string): boolean {
    const initialLen = this.schema.orders.length;
    this.schema.orders = this.schema.orders.filter(o => o.id !== id);
    if (this.schema.orders.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }
}

export const db = new JsonDb();
