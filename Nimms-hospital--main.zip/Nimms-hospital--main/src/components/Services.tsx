/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SERVICES_DATA, HOSPITAL_NAME } from '../data';
import { ShieldCheck, Check, HeartPulse, Sparkles, PhoneCall } from 'lucide-react';

interface ServicesProps {
  onBookAppointment: () => void;
}

export default function Services({ onBookAppointment }: ServicesProps) {
  return (
    <div className="font-sans text-slate-800 antialiased pt-24 text-left">
      
      {/* Visual Header */}
      <section className="bg-slate-900 text-white relative py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          <img 
            src="https://images.unsplash.com/photo-1512438248247-f0f2a5a8b7f0?auto=format&fit=crop&q=80&w=1200" 
            alt="NIMMS Hospital Core Operations" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-transparent" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-cyan-400">Clinical Support Infrastructure</span>
          <h1 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl mt-2 text-white">Ancillary Medical Services</h1>
          <p className="text-slate-350 mt-4 max-w-2xl text-sm leading-relaxed">
            Continuous health operations encompassing high-Tesla resonance scanning, 24/7 medicine dispensaries, and advanced diagnostic laboratories.
          </p>
        </div>
      </section>

      {/* Services List Display */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
          
          {SERVICES_DATA.map((service, idx) => {
            const isEven = idx % 2 === 0;
            return (
              <div 
                key={service.id}
                className={`grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center ${
                  isEven ? '' : 'lg:flex-row-reverse'
                }`}
              >
                
                {/* Visual Image */}
                <div className={`lg:col-span-6 relative rounded-3xl overflow-hidden shadow-2xl group ${
                  isEven ? 'lg:order-1' : 'lg:order-2'
                }`}>
                  <div className="absolute -inset-2 bg-gradient-to-r from-cyan-600 to-blue-500 rounded-2xl blur opacity-10" />
                  <div className="relative rounded-2xl overflow-hidden bg-slate-50 border border-slate-100">
                    <img 
                      src={service.bannerImage} 
                      alt={service.title} 
                      className="w-full h-80 sm:h-[350px] object-cover transition-transform duration-500 group-hover:scale-103"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute bottom-4 left-4 bg-slate-900/80 backdrop-blur-sm border border-slate-750/50 px-4 py-2.5 rounded-xl text-white text-xs font-bold font-sans flex items-center gap-1.5 shadow-md">
                      <Sparkles size={13} className="text-cyan-400 animate-pulse" />
                      <span>Certified Quality System</span>
                    </div>
                  </div>
                </div>

                {/* Content info card */}
                <div className={`lg:col-span-6 space-y-6 ${
                  isEven ? 'lg:order-2' : 'lg:order-1'
                }`}>
                  <div className="flex items-center gap-2 text-cyan-600 font-bold text-xs uppercase tracking-widest pl-1">
                    <span className="w-1.5 h-1.5 bg-cyan-600 rounded-full" />
                    <span>Diagnostics & Facilities</span>
                  </div>
                  
                  <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-slate-900 leading-snug">
                    {service.title}
                  </h2>
                  
                  <p className="text-sm text-slate-500 leading-relaxed font-normal">
                    {service.description}
                  </p>

                  {/* Bullet Spec Grid */}
                  <div className="space-y-3.5 pt-4 border-t border-slate-100/80 text-xs text-slate-500 font-normal">
                    {service.detailPoints.map((point, index) => (
                      <div key={index} className="flex items-start gap-2.5">
                        <div className="w-4 h-4 rounded-full bg-cyan-50 border border-cyan-150 text-cyan-500 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Check size={11} />
                        </div>
                        <span className="leading-relaxed">{point}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-6">
                    <button
                      onClick={onBookAppointment}
                      id={`service-book-${service.id}`}
                      className="bg-slate-900 hover:bg-slate-800 text-white font-sans font-bold text-xs tracking-wider uppercase px-6 py-3.5 rounded-xl transition-all shadow-md flex items-center gap-2 block w-full sm:w-auto text-center justify-center active:scale-95"
                    >
                      <HeartPulse size={14} className="text-cyan-400" />
                      <span>Schedule Allied Service</span>
                    </button>
                  </div>
                </div>

              </div>
            );
          })}

        </div>
      </section>

      {/* Support helpline banner */}
      <section className="py-20 bg-slate-50 border-t border-slate-150 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900 text-white rounded-3xl p-8 md:p-12 text-center max-w-4xl mx-auto relative overflow-hidden border border-slate-800 shadow-2xl">
            <div className="absolute top-0 right-0 w-80 h-80 rounded-full bg-cyan-500/5 blur-[100px] pointer-events-none" />
            <div className="relative z-10">
              <span className="text-[10px] uppercase font-extrabold tracking-widest text-cyan-400 block mb-2">Patient HelpDesk Matrix</span>
              <h3 className="font-display font-black text-2xl sm:text-3xl text-white">Need Customized Healthcare Pricing?</h3>
              <p className="text-slate-350 text-xs md:text-sm max-w-xl mx-auto mt-4 leading-relaxed font-normal">
                If you have private insurance cards or corporate policies, our administrative coordinators can assist you in verifying pre-authorization rules completely.
              </p>
              
              <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  onClick={onBookAppointment}
                  className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs tracking-widest uppercase px-6 py-3.5 rounded-xl transition-all shadow-lg w-full sm:w-auto"
                >
                  Consult AdmissionsDesk
                </button>
                <a
                  href="tel:+911149876543"
                  className="bg-transparent hover:bg-slate-800 text-cyan-400 font-bold text-xs border border-slate-700 hover:border-slate-650 px-6 py-3.5 rounded-xl transition-all w-full sm:w-auto flex items-center justify-center gap-1.5"
                >
                  <PhoneCall size={14} />
                  <span>Call Desk: +91 11 4987 6543</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
