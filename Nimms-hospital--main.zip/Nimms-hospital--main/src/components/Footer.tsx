/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import Logo from './Logo';
import { Mail, Phone, MapPin, Clock, ArrowUpRight, ShieldAlert, FileText, Globe } from 'lucide-react';
import { HOSPITAL_NAME, HOSPITAl_TAGLINE, EMERGENCY_PHONE, INFO_EMAIL, ADDRESS, DEPARTMENTS_DATA } from '../data';

interface FooterProps {
  onPageChange: (pageId: string) => void;
  onBookAppointment: () => void;
}

export default function Footer({ onPageChange, onBookAppointment }: FooterProps) {
  const handleNavClick = (pageId: string) => {
    onPageChange(pageId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const socialLinks = [
    { name: 'Facebook', href: '#', icon: 'M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1V12h3l-.5 3h-2.5v6.8c4.56-.93 8-4.96 8-9.8z' },
    { name: 'Twitter', href: '#', icon: 'M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z' },
    { name: 'LinkedIn', href: '#', icon: 'M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.779-1.75-1.75s.784-1.75 1.75-1.75 1.75.779 1.75 1.75-.784 1.75-1.75 1.75zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z' }
  ];

  return (
    <footer className="bg-slate-900 text-slate-300 font-sans relative z-10 overflow-hidden pt-16 pb-8 border-t border-slate-800">
      
      {/* Decorative gradient light overlays */}
      <div className="absolute top-0 right-0 w-80 h-80 rounded-full bg-cyan-500/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full bg-blue-500/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Emergency Highlight Banner */}
        <div className="bg-slate-800/60 border border-slate-700/50 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row justify-between items-center gap-6 mb-12">
          <div className="flex items-center gap-4 text-left">
            <div className="p-3.5 bg-red-500/10 text-red-500 rounded-xl border border-red-500/20 shadow-md">
              <ShieldAlert size={26} className="animate-bounce" />
            </div>
            <div>
              <h3 className="font-display font-bold text-white text-lg md:text-xl leading-snug">Are you experiencing a medical emergency?</h3>
              <p className="text-sm text-slate-400 mt-1">Our certified trauma squad is ready 24 hours a day to save lives.</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto">
            <a 
              href={`tel:${EMERGENCY_PHONE}`} 
              className="w-full sm:w-auto bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold text-sm tracking-wide uppercase px-6 py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-red-600/10"
            >
              <Phone size={16} />
              <span>Call Dispatch: {EMERGENCY_PHONE}</span>
            </a>
            <button 
              onClick={onBookAppointment}
              className="w-full sm:w-auto bg-slate-700 hover:bg-slate-600 active:scale-95 text-white font-bold text-sm px-6 py-3.5 rounded-xl transition-all border border-slate-600 flex items-center justify-center gap-2"
            >
              <span>Instant Appointment</span>
              <ArrowUpRight size={16} />
            </button>
          </div>
        </div>

        {/* 4-Column Directory Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12 pb-12 border-b border-slate-800">
          
          {/* Col 1: Brand & Bio */}
          <div className="flex flex-col gap-6 text-left">
            <Logo lightMode={true} />
            <p className="text-sm text-slate-400 leading-relaxed">
              NIMMS Hospital is dedicated to raising healthcare standards globally by combining state-of-the-art diagnostic facilities and award-winning doctors with a warm, caring community atmosphere.
            </p>
            <div className="flex items-center gap-3">
              {socialLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  className="w-9 h-9 rounded-lg bg-slate-800 hover:bg-cyan-600 text-slate-400 hover:text-white flex items-center justify-center transition-all"
                  aria-label={link.name}
                >
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d={link.icon} />
                  </svg>
                </a>
              ))}
            </div>
          </div>

          {/* Col 2: Services Directory */}
          <div className="flex flex-col gap-4 text-left">
            <h4 className="font-display font-bold text-white text-sm uppercase tracking-widest border-l-2 border-cyan-500 pl-2.5">
              Medical Disciplines
            </h4>
            <div className="flex flex-col gap-2">
              {DEPARTMENTS_DATA.map((dept) => (
                <button
                  key={dept.id}
                  onClick={() => handleNavClick('departments')}
                  className="text-sm text-slate-400 hover:text-cyan-400 text-left transition-all flex items-center gap-1.5 focus:outline-none"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-700" />
                  <span>{dept.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Col 3: Navigation Links */}
          <div className="flex flex-col gap-4 text-left">
            <h4 className="font-display font-bold text-white text-sm uppercase tracking-widest border-l-2 border-cyan-500 pl-2.5">
              Quick Links
            </h4>
            <div className="flex flex-col gap-2">
              <button onClick={() => handleNavClick('about')} className="text-sm text-slate-400 hover:text-cyan-400 text-left transition-all">About Our Legacy</button>
              <button onClick={() => handleNavClick('doctors')} className="text-sm text-slate-400 hover:text-cyan-400 text-left transition-all">Meet Our Clinicians</button>
              <button onClick={() => handleNavClick('services')} className="text-sm text-slate-400 hover:text-cyan-400 text-left transition-all">Ancillary Services</button>
              <button onClick={() => handleNavClick('contact')} className="text-sm text-slate-400 hover:text-cyan-400 text-left transition-all">Get Direction Matrix</button>
              <a href="#" className="text-sm text-slate-400 hover:text-cyan-400 text-left transition-all flex items-center gap-1.5">
                <FileText size={14} />
                <span>Patient Portal Terms</span>
              </a>
              <a href="#" className="text-sm text-slate-400 hover:text-cyan-400 text-left transition-all flex items-center gap-1.5">
                <Globe size={14} />
                <span>Sitemap Directory</span>
              </a>
              <button 
                onClick={() => handleNavClick('admin')} 
                className="text-sm text-cyan-500 font-bold hover:text-cyan-400 text-left transition-all flex items-center gap-1.5 focus:outline-none mt-1"
              >
                <ShieldAlert size={14} className="text-cyan-500" />
                <span>Staff Admin Portal</span>
              </button>
            </div>
          </div>

          {/* Col 4: Reach Us Directly */}
          <div className="flex flex-col gap-4 text-left">
            <h4 className="font-display font-bold text-white text-sm uppercase tracking-widest border-l-2 border-cyan-500 pl-2.5">
              Campuses & Contact
            </h4>
            <div className="flex flex-col gap-3.5 text-sm text-slate-400">
              <div className="flex gap-2.5">
                <MapPin size={18} className="text-cyan-400 flex-shrink-0" />
                <span>{ADDRESS}</span>
              </div>
              <div className="flex gap-2.5">
                <Mail size={16} className="text-cyan-400 flex-shrink-0" />
                <a href={`mailto:${INFO_EMAIL}`} className="hover:text-cyan-400 break-all">{INFO_EMAIL}</a>
              </div>
              <div className="flex gap-2.5">
                <Clock size={16} className="text-cyan-400 flex-shrink-0" />
                <div>
                  <p className="font-semibold text-slate-300">OPD Consultation:</p>
                  <p className="text-xs">Mon - Sat: 9:00 AM - 8:00 PM</p>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Attributions */}
        <div className="pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <p>© 2026 {HOSPITAL_NAME}. All clinical rights reserved. Designed for elite patient trust.</p>
          <div className="flex items-center gap-5">
            <a href="#" className="hover:text-slate-400 transition-all">Privacy Policy</a>
            <span className="w-1.5 h-1.5 bg-slate-700 rounded-full" />
            <a href="#" className="hover:text-slate-400 transition-all">Patient Rights Act</a>
            <span className="w-1.5 h-1.5 bg-slate-700 rounded-full" />
            <a href="#" className="hover:text-slate-400 transition-all">NABH Licensing</a>
          </div>
        </div>

      </div>
    </footer>
  );
}
