/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Calendar, User, Phone, Clipboard, FileText, CheckCircle, ShieldCheck, Heart, Clock } from 'lucide-react';
import { DEPARTMENTS_DATA, DOCTORS_DATA, HOSPITAL_NAME } from '../data';
import { Appointment } from '../types';

interface AppointmentFormProps {
  embeddedMode?: boolean;
  onSuccessClose?: () => void;
  selectedDeptId?: string;
  selectedDoctorId?: string;
}

export default function AppointmentForm({ 
  embeddedMode = false, 
  onSuccessClose, 
  selectedDeptId = '', 
  selectedDoctorId = '' 
}: AppointmentFormProps) {
  const [formData, setFormData] = useState<Appointment>({
    name: '',
    phone: '',
    department: selectedDeptId || DEPARTMENTS_DATA[0].id,
    doctor: selectedDoctorId || DOCTORS_DATA.filter(doc => doc.specialtyId === (selectedDeptId || DEPARTMENTS_DATA[0].id))[0]?.id || '',
    date: '',
    timeSlot: '09:00 AM - 10:00 AM',
    notes: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [ticketNumber, setTicketNumber] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const filteredDoctors = DOCTORS_DATA.filter(doc => doc.specialtyId === formData.department);

  const handleDepartmentChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const deptId = e.target.value;
    const firstDocInDept = DOCTORS_DATA.find(doc => doc.specialtyId === deptId);
    setFormData(prev => ({
      ...prev,
      department: deptId,
      doctor: firstDocInDept ? firstDocInDept.id : ''
    }));
  };

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    if (!formData.name.trim()) newErrors.name = 'Full Name is required.';
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone Number is required.';
    } else if (!/^[0-9+\s-]{10,15}$/.test(formData.phone.replace(/\s+/g, ''))) {
      newErrors.phone = 'Please key in a valid 10-digit mobile number.';
    }
    if (!formData.date) newErrors.date = 'Please select a preferred clinic date.';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    setErrors({});
    
    try {
      const res = await fetch('/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });

      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.error || 'Failed to register appointment queue slot.');
      }

      setIsSuccess(true);
      setTicketNumber(data.appointment.id);
    } catch (err: any) {
      setErrors({ submit: err.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const timeSlots = [
    '09:00 AM - 10:00 AM',
    '10:00 AM - 11:00 AM',
    '11:00 AM - 12:00 PM',
    '12:00 PM - 01:00 PM',
    '02:00 PM - 03:00 PM',
    '03:00 PM - 04:00 PM',
    '04:00 PM - 05:00 PM',
    '05:00 PM - 06:00 PM',
  ];

  if (isSuccess) {
    const chosenDept = DEPARTMENTS_DATA.find(d => d.id === formData.department);
    const chosenDoctor = DOCTORS_DATA.find(d => d.id === formData.doctor);

    return (
      <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 md:p-8 text-center max-w-lg mx-auto shadow-xl flex flex-col items-center justify-center animate-fade-in text-slate-800">
        <div className="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center border border-emerald-150 mb-4 animate-bounce">
          <CheckCircle size={32} />
        </div>
        <h3 className="font-display font-extrabold text-2xl text-slate-900 leading-snug">Appointment Booked!</h3>
        <p className="text-sm text-slate-500 mt-2">
          Your reservation request has been successfully synchronized onto NIMMS' medical schedule queue.
        </p>

        {/* Custom Booking Card Receipt */}
        <div className="w-full mt-6 bg-white border border-dashed border-slate-200 rounded-xl p-5 text-left text-xs space-y-3 relative overflow-hidden shadow-sm">
          <div className="absolute top-0 right-0 bg-emerald-600 text-white font-bold font-mono px-3 py-1 rounded-bl-xl uppercase tracking-widest text-[9px]">
            Confirmed
          </div>
          <div className="border-b border-slate-100 pb-2.5 flex justify-between items-center">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Appointment ID</span>
              <p className="font-mono text-sm font-black text-cyan-600 mt-0.5">{ticketNumber}</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Department</span>
              <p className="font-semibold text-slate-700 mt-0.5">{chosenDept?.name}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <span className="text-slate-400 font-medium">Patient Name:</span>
              <p className="font-bold text-slate-800 mt-0.5">{formData.name}</p>
            </div>
            <div>
              <span className="text-slate-400 font-medium">Contact Number:</span>
              <p className="font-mono text-slate-800 mt-0.5">{formData.phone}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-1">
            <div>
              <span className="text-slate-400 font-medium">Physician:</span>
              <p className="font-bold text-slate-800 mt-0.5">{chosenDoctor?.name || 'Assigned Specialist'}</p>
            </div>
            <div>
              <span className="text-slate-400 font-medium">Treatment Day:</span>
              <p className="font-semibold text-slate-800 mt-0.5">{formData.date} at {formData.timeSlot.split(' - ')[0]}</p>
            </div>
          </div>

          <div className="bg-slate-50/80 p-2.5 rounded-lg border border-slate-100 mt-1 flex items-center gap-2 text-[10px] text-slate-500">
            <ShieldCheck size={14} className="text-cyan-500 flex-shrink-0" />
            <span>Please present this ID or mobile SMS confirmation at block reception desk A.</span>
          </div>
        </div>

        <div className="mt-8 flex gap-3 w-full">
          {onSuccessClose ? (
            <button
              onClick={onSuccessClose}
              className="w-full bg-slate-900 text-white font-bold py-3.5 rounded-xl transition-all hover:bg-slate-800 text-sm focus:outline-none"
            >
              Close Receipt
            </button>
          ) : (
            <button
              onClick={() => setIsSuccess(false)}
              className="w-full bg-cyan-600 text-white font-bold py-3.5 rounded-xl transition-all hover:bg-cyan-700 text-sm focus:outline-none"
            >
              Book Another Session
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={`text-slate-800 text-left bg-white rounded-2xl ${
      embeddedMode ? 'border border-slate-100/80 p-0 shadow-none' : 'border border-slate-100 p-6 md:p-8 shadow-xl'
    }`}>
      {!embeddedMode && (
        <div className="mb-6">
          <div className="flex items-center gap-2 text-cyan-500 mb-1.5">
            <Heart size={16} className="text-red-500 animate-pulse" />
            <span className="text-[11px] font-extrabold uppercase tracking-widest">{HOSPITAL_NAME} Scheduler</span>
          </div>
          <h3 className="font-display font-extrabold text-2xl text-slate-900 leading-snug">Secure Clinic Booking</h3>
          <p className="text-sm text-slate-500 mt-1">
            Choose your physician, pick a preferred calendar spot, and sync with our consulting boards instantly.
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Full Name */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center gap-1.5">
            <User size={13} className="text-cyan-500" />
            <span>Patient's Full Name</span>
          </label>
          <input
            type="text"
            required
            className="w-full px-4 py-3 bg-slate-50 border border-slate-250 rounded-xl focus:border-cyan-500 focus:bg-white outline-none transition-all text-sm shadow-inner"
            placeholder="e.g. Anand Gupta"
            value={formData.name}
            onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
          />
          {errors.name && <p className="text-red-500 text-[11px] font-semibold mt-1">{errors.name}</p>}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Mobile Number */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center gap-1.5">
              <Phone size={13} className="text-cyan-500" />
              <span>Contact Mobile</span>
            </label>
            <input
              type="tel"
              required
              className="w-full px-4 py-3 bg-slate-50 border border-slate-250 rounded-xl focus:border-cyan-500 focus:bg-white outline-none transition-all text-sm shadow-inner"
              placeholder="e.g. +91 98765 XXXXX"
              value={formData.phone}
              onChange={e => setFormData(p => ({ ...p, phone: e.target.value }))}
            />
            {errors.phone && <p className="text-red-500 text-[11px] font-semibold mt-1">{errors.phone}</p>}
          </div>

          {/* Department Selection */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center gap-1.5">
              <Clipboard size={13} className="text-cyan-500" />
              <span>Medical Specialty</span>
            </label>
            <select
              className="w-full px-3 py-3 bg-slate-50 border border-slate-250 rounded-xl focus:border-cyan-500 focus:bg-white outline-none transition-all text-sm"
              value={formData.department}
              onChange={handleDepartmentChange}
            >
              {DEPARTMENTS_DATA.map(dept => (
                <option key={dept.id} value={dept.id}>{dept.name}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Clinical Doctor Consultation */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center gap-1.5">
              <User size={13} className="text-cyan-500" />
              <span>Assigned Specialist</span>
            </label>
            <select
              className="w-full px-3 py-3 bg-slate-50 border border-slate-250 rounded-xl focus:border-cyan-500 focus:bg-white outline-none transition-all text-sm"
              value={formData.doctor}
              onChange={e => setFormData(p => ({ ...p, doctor: e.target.value }))}
            >
              {filteredDoctors.map(doc => (
                <option key={doc.id} value={doc.id}>{doc.name} ({doc.role.split(' ')[0]})</option>
              ))}
              {filteredDoctors.length === 0 && (
                <option value="">Any Available Specialist</option>
              )}
            </select>
          </div>

          {/* Preferred Consultation Date */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center gap-1.5">
              <Calendar size={13} className="text-cyan-500" />
              <span>Preferred Date</span>
            </label>
            <input
              type="date"
              required
              min={new Date().toISOString().split('T')[0]}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-250 rounded-xl focus:border-cyan-500 focus:bg-white outline-none transition-all text-sm shadow-inner"
              value={formData.date}
              onChange={e => setFormData(p => ({ ...p, date: e.target.value }))}
            />
            {errors.date && <p className="text-red-500 text-[11px] font-semibold mt-1">{errors.date}</p>}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Available Hour Block Selection */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center gap-1.5">
              <Clock size={13} className="text-cyan-500" />
              <span>Preferred Time Window</span>
            </label>
            <select
              className="w-full px-3 py-3 bg-slate-50 border border-slate-250 rounded-xl focus:border-cyan-500 focus:bg-white outline-none transition-all text-sm"
              value={formData.timeSlot}
              onChange={e => setFormData(p => ({ ...p, timeSlot: e.target.value }))}
            >
              {timeSlots.map(slot => (
                <option key={slot} value={slot}>{slot}</option>
              ))}
            </select>
          </div>

          {/* Additional Notes */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center gap-1.5">
              <FileText size={13} className="text-cyan-500" />
              <span>Symptoms / Health Remarks</span>
            </label>
            <input
              type="text"
              className="w-full px-4 py-3 bg-slate-50 border border-slate-250 rounded-xl focus:border-cyan-500 focus:bg-white outline-none transition-all text-sm shadow-inner"
              placeholder="e.g. Regular health assessment, checkup"
              value={formData.notes}
              onChange={e => setFormData(p => ({ ...p, notes: e.target.value }))}
            />
          </div>
        </div>

        {errors.submit && (
          <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs font-semibold text-center animate-fade-in">
            {errors.submit}
          </div>
        )}

        <button
          type="submit"
          disabled={isSubmitting}
          id="confirm-booking-btn"
          className="w-full mt-6 bg-cyan-600 hover:bg-cyan-700 active:scale-[0.99] disabled:bg-cyan-400 text-white font-sans font-bold py-4 rounded-xl transition-all shadow-lg shadow-cyan-600/10 uppercase tracking-widest text-xs flex items-center justify-center gap-2 focus:outline-none"
        >
          {isSubmitting ? (
            <>
              <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              <span>Synchronizing Slots...</span>
            </>
          ) : (
            <>
              <span>Confirm Patient Booking</span>
            </>
          )}
        </button>

        <p className="text-[10px] text-center text-slate-400 leading-relaxed mt-2.5">
          By submitting this, you acknowledge synchronization under our Hospital Privacy Act regulations. No clinical data is shared with external services.
        </p>
      </form>
    </div>
  );
}
