/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HOSPITAL_NAME, ADDRESS, EMERGENCY_PHONE, INFO_EMAIL, APP_PHONE } from '../data';
import { MapPin, Phone, Mail, Clock, Send, MessageSquare, Plus, Minus, CheckCircle, ShieldCheck } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'General Inquiry',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!formData.name.trim()) errs.name = 'Full Name is required.';
    if (!formData.email.trim() || !/\S+@\S+\.\S+/.test(formData.email)) errs.email = 'Please provide a valid email.';
    if (!formData.phone.trim()) errs.phone = 'Mobile is required.';
    if (!formData.message.trim()) errs.message = 'Please type your message.';
    
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleDispatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: 'General Inquiry',
        message: ''
      });
    }, 1500);
  };

  // FAQ states
  const [activeFaqIdx, setActiveFaqIdx] = useState<number | null>(0);

  const faqs = [
    {
      q: "What are your OPD consulting timings?",
      a: "Our Outpatient Departments (OPD) operate from Monday to Saturday, between 9:00 AM and 8:00 PM. We advise scheduling appointment locks at least 24 hours earlier to secure preferred specialist seats."
    },
    {
      q: "Do you have tie-ups with private insurances?",
      a: "Yes. NIMMS Hospital supports cashless therapeutic entries for leading national and international medical insurance networks. Our desk assistance managers can guide you during patient check-in."
    },
    {
      q: "What details do I present during admissions checkup?",
      a: "Please present your doctor prescription note, verified government photo ID (Aadhaar/License), and medical insurance cards, alongside any prior diagnostic scans."
    },
    {
      q: "Is emergency trauma care active during state holidays?",
      a: "Yes. Our Emergency Trauma Department, cardiac life rescue responders, diagnostic labs, and critical ward beds operate 24 hours a day, 365 days a year without absolute interruptions."
    }
  ];

  return (
    <div className="font-sans text-slate-800 antialiased pt-24 text-left">
      
      {/* Visual Header */}
      <section className="bg-slate-900 text-white relative py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          <img 
            src="https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?auto=format&fit=crop&q=80&w=1200" 
            alt="NIMMS Hospital Map Location" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-transparent" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-cyan-400">Campus Coordinates</span>
          <h1 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl mt-2 text-white">Contact & Connect</h1>
          <p className="text-slate-350 mt-4 max-w-2xl text-sm leading-relaxed">
            Reach our administrative desk, ask pricing estimates, or navigate directly to our New Delhi medical campus.
          </p>
        </div>
      </section>

      {/* Main Grid: Info Cards & Feedback Form */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-start">
            
            {/* Left Column: Direct info cards */}
            <div className="lg:col-span-5 space-y-6 text-left">
              <div>
                <span className="text-[11px] font-extrabold text-cyan-600 uppercase tracking-widest">Attestation Desk</span>
                <h2 className="font-display font-extrabold text-3xl text-slate-900 mt-1 leading-snug">Attending Points</h2>
                <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                  Have inquiry questions or need general support? Get in immediate touch with our front lobby coordinators.
                </p>
              </div>

              {/* Info Block 1: Address */}
              <div className="flex gap-4 p-5 bg-slate-50 border border-slate-100 rounded-2xl">
                <div className="w-10 h-10 rounded-xl bg-cyan-50 border border-cyan-100 text-cyan-500 flex items-center justify-center flex-shrink-0">
                  <MapPin size={20} />
                </div>
                <div className="leading-relaxed">
                  <h4 className="font-display font-bold text-sm text-slate-900">Hospital Campus Address</h4>
                  <p className="text-xs text-slate-500 mt-1">{ADDRESS}</p>
                  <a 
                    href="https://maps.google.com" 
                    target="_blank" 
                    rel="noreferrer" 
                    className="text-cyan-600 hover:text-cyan-700 font-bold text-[11px] uppercase tracking-wider block mt-2 hover:underline"
                  >
                    Open in Maps →
                  </a>
                </div>
              </div>

              {/* Info Block 2: Hotline */}
              <div className="flex gap-4 p-5 bg-slate-50 border border-slate-100 rounded-2xl">
                <div className="w-10 h-10 rounded-xl bg-red-50 border border-red-100 text-red-550 flex items-center justify-center flex-shrink-0">
                  <Phone size={18} className="animate-bounce" />
                </div>
                <div className="leading-relaxed">
                  <h4 className="font-display font-bold text-sm text-slate-900">Direct Telephone Directives</h4>
                  <p className="text-xs text-slate-500 mt-1">24/7 Trauma Emergency Hotline: <span className="font-mono font-bold text-slate-800">{EMERGENCY_PHONE}</span></p>
                  <p className="text-xs text-slate-500 mt-1">OPD Booking Desk: <span className="font-mono font-bold text-slate-800">{APP_PHONE}</span></p>
                </div>
              </div>

              {/* Info Block 3: Mail & Hours */}
              <div className="flex gap-4 p-5 bg-slate-50 border border-slate-100 rounded-2xl">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-500 flex items-center justify-center flex-shrink-0">
                  <Mail size={18} />
                </div>
                <div className="leading-relaxed">
                  <h4 className="font-display font-bold text-sm text-slate-900">Email & Consultation Hours</h4>
                  <p className="text-xs text-slate-500 mt-1">Mailing Address: <a href={`mailto:${INFO_EMAIL}`} className="text-cyan-600 hover:underline">{INFO_EMAIL}</a></p>
                  <p className="text-xs text-slate-500 mt-1">OPD Windows: Mon-Sat: 09:00 AM - 08:00 PM</p>
                </div>
              </div>

            </div>

            {/* Right Column: Feedback dispatch slate */}
            <div className="lg:col-span-7 bg-white border border-slate-100 rounded-3xl p-6 md:p-8 shadow-xl shadow-slate-100/50">
              
              {isSuccess ? (
                <div className="py-12 px-4 text-center space-y-4 animate-fade-in text-slate-800">
                  <div className="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center border border-emerald-100 mx-auto mb-2 animate-bounce">
                    <CheckCircle size={32} />
                  </div>
                  <h3 className="font-display font-extrabold text-2xl text-slate-900">Message Dispatched!</h3>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                    Thank you for connecting with NIMMS. An administrative manager has queued your ticket and will trace your mobile contact within 24 working hours.
                  </p>
                  <button
                    onClick={() => setIsSuccess(false)}
                    className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs tracking-wider uppercase px-6 py-3 rounded-lg transition-all"
                  >
                    Send Another Ticket
                  </button>
                </div>
              ) : (
                <form onSubmit={handleDispatch} className="space-y-4 text-left">
                  <div className="flex items-center gap-2 text-cyan-500 mb-2">
                    <MessageSquare size={16} />
                    <span className="text-[11px] font-extrabold uppercase tracking-widest">Connect Matrix</span>
                  </div>
                  <h3 className="font-display font-extrabold text-xl text-slate-900">Send Direct Feedback</h3>
                  <p className="text-xs text-slate-400">Ask billing terms, submit clinical feedback, or report experiences.</p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
                    {/* Name */}
                    <div>
                      <input
                        type="text"
                        required
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-cyan-500 focus:bg-white outline-none rounded-xl text-xs transition-all"
                        placeholder="Your Full Name"
                        value={formData.name}
                        onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
                      />
                      {errors.name && <p className="text-red-500 text-[10px] font-semibold mt-1">{errors.name}</p>}
                    </div>

                    {/* Email */}
                    <div>
                      <input
                        type="email"
                        required
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-cyan-500 focus:bg-white outline-none rounded-xl text-xs transition-all"
                        placeholder="Mailing Address"
                        value={formData.email}
                        onChange={e => setFormData(p => ({ ...p, email: e.target.value }))}
                      />
                      {errors.email && <p className="text-red-500 text-[10px] font-semibold mt-1">{errors.email}</p>}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Mobile */}
                    <div>
                      <input
                        type="tel"
                        required
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-cyan-500 focus:bg-white outline-none rounded-xl text-xs transition-all"
                        placeholder="Mobile Code Number"
                        value={formData.phone}
                        onChange={e => setFormData(p => ({ ...p, phone: e.target.value }))}
                      />
                      {errors.phone && <p className="text-red-500 text-[10px] font-semibold mt-1">{errors.phone}</p>}
                    </div>

                    {/* Subject */}
                    <div>
                      <select
                        className="w-full px-3 py-3 bg-slate-50 border border-slate-200 focus:border-cyan-500 focus:bg-white outline-none rounded-xl text-xs transition-all"
                        value={formData.subject}
                        onChange={e => setFormData(p => ({ ...p, subject: e.target.value }))}
                      >
                        <option value="General Inquiry">General Inquiry</option>
                        <option value="Billing & Pricing">Billing & Pricing</option>
                        <option value="Specialty Consultation">Specialty Consultation</option>
                        <option value="Feedback & Suggestions">Feedback & Suggestions</option>
                      </select>
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <textarea
                      required
                      rows={5}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-cyan-500 focus:bg-white outline-none rounded-xl text-xs transition-all resize-none shadow-inner"
                      placeholder="Type your message details..."
                      value={formData.message}
                      onChange={e => setFormData(p => ({ ...p, message: e.target.value }))}
                    />
                    {errors.message && <p className="text-red-500 text-[10px] font-semibold mt-1">{errors.message}</p>}
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-cyan-600 hover:bg-cyan-700 active:scale-[0.99] disabled:bg-cyan-400 text-white font-sans font-bold py-3.5 rounded-xl transition-all shadow-md uppercase text-xs flex items-center justify-center gap-2 focus:outline-none"
                  >
                    {isSubmitting ? (
                      <>
                        <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        <span>Dispatching...</span>
                      </>
                    ) : (
                      <>
                        <Send size={13} />
                        <span>Send Ticket</span>
                      </>
                    )}
                  </button>

                </form>
              )}

            </div>

          </div>
        </div>
      </section>

      {/* FAQ SECTION */}
      <section className="py-20 bg-slate-50 border-t border-slate-100 text-left">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          
          <div className="text-center mb-12">
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-cyan-600">Patient Guidelines</span>
            <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-slate-900 mt-1">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-3.5">
            {faqs.map((faq, idx) => {
              const isOpen = activeFaqIdx === idx;
              return (
                <div 
                  key={idx}
                  className="bg-white border border-slate-100 rounded-2xl overflow-hidden transition-all duration-300"
                >
                  <button
                    onClick={() => setActiveFaqIdx(isOpen ? null : idx)}
                    className="w-full p-5 text-left font-display font-bold text-slate-900 text-sm md:text-base flex justify-between items-center bg-transparent hover:bg-slate-50/50 transition-colors focus:outline-none"
                  >
                    <span>{faq.q}</span>
                    <span className="p-1 px-1.5 bg-slate-50 border border-slate-100 rounded-lg text-slate-500">
                      {isOpen ? <Minus size={14} /> : <Plus size={14} />}
                    </span>
                  </button>
                  
                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-slate-500 text-xs sm:text-sm leading-relaxed border-t border-slate-50 animate-fade-in font-normal">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* Modern Mock google maps placeholder to resemble local business in Thakur... */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="w-full text-center mb-6">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-cyan-600">Location Guide</span>
            <h4 className="font-display font-extrabold text-[15px] mt-1 text-slate-900">Map Registry & Transit</h4>
          </div>
          
          {/* Detailed Graphic Maps box resembling Google Maps index */}
          <div className="border border-slate-200/80 rounded-3xl overflow-hidden shadow-2xl bg-slate-50 h-[380px] relative flex items-center justify-center group select-none">
            {/* Styled Map Artwork background with gridlines and lines */}
            <svg className="absolute inset-0 w-full h-full text-slate-300/45 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="mapPattern" width="60" height="60" patternUnits="userSpaceOnUse">
                  <path d="M 60 0 L 0 0 0 60" fill="none" stroke="currentColor" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#mapPattern)" />
              {/* Roads drawing */}
              <path d="M 0 100 Q 300 200, 1200 150" fill="none" stroke="#FFFFFF" strokeWidth="24" />
              <path d="M 0 100 Q 300 200, 1200 150" fill="none" stroke="#CBD5E1" strokeWidth="16" />
              <path d="M 400 0 L 500 380" fill="none" stroke="#FFFFFF" strokeWidth="20" />
              <path d="M 400 0 L 500 380" fill="none" stroke="#CBD5E1" strokeWidth="12" />
              <path d="M 120 0 L 800 380" fill="none" stroke="#FFFFFF" strokeWidth="16" />
              <path d="M 120 0 L 800 380" fill="none" stroke="#CBD5E1" strokeWidth="8" />
              {/* Park representation */}
              <circle cx="200" cy="240" r="80" fill="#E2F0D9" opacity="0.8" />
              <circle cx="850" cy="100" r="110" fill="#E2F0D9" opacity="0.8" />
              <text x="200" y="240" fill="#7E9F6E" fontSize="9" fontFamily="sans-serif" textAnchor="middle" fontWeight="bold">RESTORATIVE GARDENS</text>
            </svg>

            {/* Glowing Map pin centering NIMMS Hospital */}
            <div className="relative z-10 flex flex-col items-center">
              <span className="absolute -top-1 w-6 h-6 rounded-full bg-cyan-500/25 animate-ping" />
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-cyan-600 to-blue-600 border-4 border-white shadow-xl flex items-center justify-center text-white relative">
                <MapPin size={22} className="text-white" />
              </div>
              <div className="bg-slate-900 text-white rounded-2xl p-4.5 border border-slate-800 shadow-2xl mt-4 max-w-sm text-left">
                <div className="flex items-center gap-2 text-cyan-400 mb-1.5">
                  <ShieldCheck size={14} />
                  <span className="text-[10px] font-extrabold uppercase tracking-widest">{HOSPITAL_NAME}</span>
                </div>
                <h5 className="font-display font-bold text-xs text-white leading-none">Attestation Campus Terminal A</h5>
                <p className="text-[10px] text-slate-400 mt-1 font-sans">{ADDRESS}</p>
                <div className="mt-3.5 border-t border-slate-800 pt-2 flex justify-between items-center">
                  <span className="text-[9px] text-emerald-400 font-mono font-bold leading-none uppercase tracking-wide">● active checkins live</span>
                  <a 
                    href="https://google.com/maps" 
                    target="_blank" 
                    rel="noreferrer" 
                    className="text-cyan-400 font-bold font-sans text-[10px] uppercase hover:underline"
                  >
                    Open Google Maps
                  </a>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </section>

    </div>
  );
}
