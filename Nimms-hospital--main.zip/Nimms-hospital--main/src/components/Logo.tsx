/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface LogoProps {
  className?: string;
  iconOnly?: boolean;
  lightMode?: boolean;
}

export default function Logo({ className = '', iconOnly = false, lightMode = false }: LogoProps) {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Custom Icon: Red Heart wrapping a Teal/Aqua Medical Cross */}
      <div className="relative w-10 h-10 flex-shrink-0">
        <svg 
          viewBox="0 0 100 100" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg" 
          className="w-full h-full drop-shadow-md"
        >
          {/* Heart Shape representation */}
          <path 
            d="M50 85C35 73.5 15 52 15 34.5C15 22.5 24.5 14 36.5 14C43.5 14 47.5 18 50 20.5C52.5 18 56.5 14 63.5 14C75.5 14 85 22.5 85 34.5C85 52 65 73.5 50 85Z" 
            fill="#EF4444" 
            className="animate-pulse"
            style={{ animationDuration: '6s' }}
          />
          
          {/* Floating White Background to give the inner cross contrast */}
          <circle cx="50" cy="40" r="24" fill="#FFFFFF" />
          
          {/* Medical Cross in Blue/Teal */}
          <path 
            d="M44 26H56V34L64 34V46H56V54H44V46H36L36 34H44V26Z" 
            fill="#06B6D4" 
          />

          {/* Abstract Mother & Child / Family Vector inside */}
          <ellipse cx="50" cy="33" rx="4" ry="4" fill="#FFFFFF" />
          <path 
            d="M42 41C42 36.5 45.5 35 50 35C54.5 35 58 36.5 58 41V44H42V41Z" 
            fill="#FFFFFF" 
          />
        </svg>
      </div>

      {!iconOnly && (
        <div className="flex flex-col leading-none">
          <span className={`font-display font-extrabold text-xl tracking-tight ${
            lightMode ? 'text-white' : 'text-slate-900'
          }`}>
            NIMMS<span className="text-cyan-500 font-semibold font-sans">+</span>
          </span>
          <span className={`font-sans font-bold text-[8px] uppercase tracking-[0.2em] ${
            lightMode ? 'text-slate-300' : 'text-slate-500'
          }`}>
            You Are Family Here
          </span>
        </div>
      )}
    </div>
  );
}
