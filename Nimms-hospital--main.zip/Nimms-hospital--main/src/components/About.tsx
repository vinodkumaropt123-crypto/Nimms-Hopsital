/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { HOSPITAL_NAME, ADDRESS, EMERGENCY_PHONE, INFO_EMAIL } from '../data';
import { ShieldCheck, Heart, Award, Users2, Activity, Gift, CheckCircle, Clock } from 'lucide-react';

interface AboutProps {
  onBookAppointment: () => void;
  onPageChange: (pageId: string) => void;
}

export default function About({ onBookAppointment, onPageChange }: AboutProps) {
  
  const values = [
    {
      title: "Patient Empathy First",
      desc: "Our founding slogan 'You Are Family Here' dictates that clinical procedures must be administered with warmth and emotional respect.",
      icon: Heart,
      color: "text-red-500 bg-red-50 border-red-100"
    },
    {
      title: "Accuracy in Diagnostics",
      desc: "We heavily invest in high-Tesla MRI systems, computerized assays, and color Doppler scanning to prevent clinical diagnosis delays.",
      icon: Activity,
      color: "text-cyan-500 bg-cyan-50 border-cyan-100"
    },
    {
      title: "Certified Integrity",
      desc: "NIMMS adheres to national quality clinical standards, boasting official licensing by the National Accreditation Board for Hospitals (NABH).",
      icon: ShieldCheck,
      color: "text-emerald-500 bg-emerald-50 border-emerald-100"
    },
    {
      title: "Caring Community Support",
      desc: "We coordinate free health screening programs and wellness education initiatives, supporting local families without financial barriers.",
      icon: Users2,
      color: "text-indigo-500 bg-indigo-50 border-indigo-100"
    }
  ];

  const timelineEvents = [
    { year: "2012", title: "Inception of NIMMS Clinic", desc: "Started as a pediatric child care centre with 3 consulting beds." },
    { year: "2016", title: "First Specialty Expand", desc: "Added general surgery and orthopedic trauma theater desks." },
    { year: "2020", title: "Full-Spectrum Corporate Hub", desc: "Constructed the blue-grid glass medical tower and introduced full diagnostic labs." },
    { year: "2024", title: "NABH Accreditation", desc: "Awarded national medical care excellence board credentials with 95%+ ratings." }
  ];

  return (
    <div className="font-sans text-slate-800 antialiased overflow-x-hidden pt-24 text-left">
      
      {/* Visual Banner Header */}
      <section className="bg-slate-900 text-white relative py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img 
            src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=1200" 
            alt="NIMMS Reception Lobby Backdrop" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-transparent" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-cyan-400">Who We Are</span>
          <h1 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl mt-2 text-white">About NIMMS Hospital</h1>
          <p className="text-slate-300 mt-4 max-w-2xl text-sm leading-relaxed">
            Delivering high-accuracy primary diagnosis and loving patient rehabilitation across New Delhi for over a decade.
          </p>
        </div>
      </section>

      {/* Intro & Reception Photo Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left: Main Reception Photo */}
            <div className="lg:col-span-6 relative">
              <div className="absolute -inset-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-2xl blur opacity-10" />
              <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-slate-50 border border-slate-100">
                <img 
                  src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=800" 
                  alt="NIMMS Admission Hub & Reception Desk" 
                  className="w-full h-[420px] object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute bottom-5 left-5 bg-slate-900/80 backdrop-blur-sm border border-slate-700/50 p-4 rounded-xl text-white text-left max-w-xs">
                  <span className="text-[10px] font-extrabold text-cyan-400 uppercase tracking-wider block">Admissions Terminal</span>
                  <p className="text-xs text-slate-300 mt-1">Our welcoming front lobby combines luxury marble finishes and illuminated corporate badges.</p>
                </div>
              </div>
            </div>

            {/* Right: History & Slogan */}
            <div className="lg:col-span-6 flex flex-col justify-center">
              <div className="inline-flex items-center gap-2 bg-cyan-50 border border-cyan-100 px-3 py-1 rounded-full text-cyan-600 text-xs font-bold uppercase tracking-wider mb-4">
                <Award size={13} />
                <span>Private Healthcare Standards</span>
              </div>
              <h2 className="font-display font-extrabold text-3xl text-slate-900 leading-tight">
                Built Around Compassion, Guided By Clinical Brilliance.
              </h2>
              <p className="text-sm text-slate-500 mt-6 leading-relaxed">
                NIMMS Hospital is India's premium medical harbor where clinical excellence aligns with our core conviction to make patients feel like immediate family members. Over the years, we have transitioned from a localized Child Care Centre into a multidisciplinary hospital complex, earning patient satisfaction ratings of over 95%.
              </p>
              <p className="text-sm text-slate-500 mt-4 leading-relaxed font-normal">
                Under the strategic vision of our Director, Dr. Alok Nath, we have created custom wings featuring ultra-clean laminar-airflow OTs, pain-free maternity rooms, and diagnostic labs running resonance and color Doppler imaging.
              </p>

              {/* Mission/Vision Box */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-100 mt-8 flex gap-4 items-start">
                <div className="p-2.5 bg-cyan-600 rounded-xl text-white mt-1">
                  <ShieldCheck size={20} />
                </div>
                <div>
                  <h4 className="font-display font-bold text-slate-900 text-sm">NABH Accredited Safety</h4>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    NIMMS operates under verified hygiene and protocol-compliant environments. Every surgical process is logged under automated auditing to prevent hospital-acquired infections completely.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Core Values Bento Grid */}
      <section className="py-20 bg-slate-50 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-cyan-600 font-sans">Core Values</span>
            <h2 className="font-display font-extrabold text-3xl text-slate-900 mt-2">What Defines Our Medical Service</h2>
            <p className="text-sm text-slate-500 mt-3 leading-relaxed">
              Every nurse, clinician, and administrative representative at NIMMS Hospital maintains these operational metrics throughout their shifts.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v, idx) => (
              <div key={idx} className="bg-white border border-slate-100/70 p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center border mb-5 ${v.color}`}>
                  <v.icon size={20} />
                </div>
                <h3 className="font-display font-bold text-slate-900 text-base">{v.title}</h3>
                <p className="text-xs text-slate-500 mt-2.5 leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* History Timeline */}
      <section className="py-20 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          
          <div className="text-center mb-14">
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-cyan-600">Our Timeline</span>
            <h2 className="font-display font-extrabold text-3xl text-slate-900 mt-1">Our Evolutionary Milestone</h2>
          </div>

          <div className="relative border-l-2 border-slate-100 pl-6 sm:pl-10 space-y-12 max-w-3xl mx-auto">
            {timelineEvents.map((t, idx) => (
              <div key={idx} className="relative">
                {/* Timeline node */}
                <span className="absolute -left-[31px] sm:-left-[47px] top-1.5 w-4 h-4 rounded-full bg-cyan-600 border-4 border-white shadow-md shadow-cyan-600/30 ring-4 ring-cyan-50" />
                
                <div className="bg-slate-50 border border-slate-100/80 p-5 rounded-2xl relative flex flex-col sm:flex-row items-start gap-4">
                  <span className="font-display font-black text-2xl text-cyan-600 leading-none sm:border-r border-slate-200 sm:pr-4">
                    {t.year}
                  </span>
                  <div>
                    <h3 className="font-display font-bold text-slate-900 text-base leading-none">{t.title}</h3>
                    <p className="text-xs text-slate-500 mt-2 leading-relaxed">{t.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Call to action panel */}
      <section className="py-16 bg-slate-900 text-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 flex flex-col items-center">
          <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-white tracking-tight">
            Consult With Our Award-Winning Board Today.
          </h2>
          <p className="text-sm text-slate-300 mt-4 max-w-xl leading-relaxed">
            Choose your specialty and pick your clinic hours. No appointment wait queues at admissions lobbies.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mt-8 w-full sm:w-auto">
            <button
              onClick={onBookAppointment}
              className="bg-cyan-600 hover:bg-cyan-700 active:scale-95 text-white font-bold text-xs tracking-wider uppercase px-8 py-3.5 rounded-xl transition-all shadow-lg"
            >
              Book Consultation Session
            </button>
            <button
              onClick={() => onPageChange('contact')}
              className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-bold text-xs tracking-wider uppercase px-8 py-3.5 rounded-xl border border-slate-700 transition-all"
            >
              Contact Hospital Campus
            </button>
          </div>
        </div>
      </section>

    </div>
  );
}
