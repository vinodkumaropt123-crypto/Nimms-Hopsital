/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import Icon from './Icon';
import { DEPARTMENTS_DATA, HOSPITAL_NAME } from '../data';
import { Calendar, Shield, Phone, Mail, ChevronRight, Check } from 'lucide-react';

interface DepartmentsProps {
  onBookAppointmentWithDept: (deptId: string) => void;
  onPageChange: (pageId: string) => void;
}

export default function Departments({ onBookAppointmentWithDept, onPageChange }: DepartmentsProps) {
  const [activeDeptId, setActiveDeptId] = useState(DEPARTMENTS_DATA[0].id);

  const selectedDept = DEPARTMENTS_DATA.find(dept => dept.id === activeDeptId) || DEPARTMENTS_DATA[0];

  return (
    <div className="font-sans text-slate-800 antialiased pt-24 text-left">
      
      {/* 1. Header Hero Panel */}
      <section className="bg-slate-900 text-white relative py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          <img 
            src="https://images.unsplash.com/photo-1579684389782-64d84b5e901a?auto=format&fit=crop&q=80&w=1200" 
            alt="NIMMS Hospital Core Operations" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-transparent" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-cyan-400">Our Clinical Capabilities</span>
          <h1 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl mt-2 text-white">Medical Specialties</h1>
          <p className="text-slate-350 mt-4 max-w-2xl text-sm leading-relaxed">
            NIMMS Hospital organizes its clinical services within specialized boards under leading clinical experts.
          </p>
        </div>
      </section>

      {/* 2. Interactive Tab System */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
            
            {/* Left Column: Department List Selectors */}
            <div className="lg:col-span-4 space-y-2 lg:sticky lg:top-28">
              <span className="text-[11px] font-extrabold text-slate-450 uppercase tracking-widest pl-2 mb-2 block">
                Select Specialty
              </span>
              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-3 space-y-1">
                {DEPARTMENTS_DATA.map((dept) => {
                  const isActive = dept.id === activeDeptId;
                  return (
                    <button
                      key={dept.id}
                      onClick={() => setActiveDeptId(dept.id)}
                      id={`dept-tab-${dept.id}`}
                      className={`w-full p-4 rounded-xl text-left font-sans font-bold text-[14px] leading-tight flex items-center justify-between transition-all group ${
                        isActive 
                          ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/10' 
                          : 'text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`p-2 rounded-lg transition-colors duration-200 ${isActive ? 'bg-cyan-500 text-white' : 'bg-white text-cyan-600 shadow-sm'}`}>
                          <Icon name={dept.icon} size={15} />
                        </span>
                        <span>{dept.name}</span>
                      </div>
                      <ChevronRight size={16} className={`transition-transform duration-200 ${isActive ? 'translate-x-1 text-white' : 'text-slate-400 group-hover:translate-x-1'}`} />
                    </button>
                  );
                })}
              </div>

              {/* Quick Support Badge */}
              <div className="bg-slate-900 text-white p-6 rounded-2xl text-left border border-slate-800 shadow-xl">
                <span className="text-[9px] uppercase font-black tracking-widest text-cyan-400">Direct Contact</span>
                <h4 className="font-display font-bold text-sm mt-1">Need Immediate Admission?</h4>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Refer directly to our trauma or admissions desks. We support fast-tracked diagnostics for early consultation.
                </p>
                <div className="mt-5 flex flex-col gap-2 font-mono text-xs">
                  <a href={`tel:${selectedDept.contactExt}`} className="text-cyan-400 font-bold hover:underline">
                    Specialty Ext: {selectedDept.contactExt}
                  </a>
                </div>
              </div>
            </div>

            {/* Right Column: Detailed Department Specs */}
            <div className="lg:col-span-8 bg-white border border-slate-100 rounded-3xl p-6 md:p-10 shadow-lg shadow-slate-50">
              
              {/* Image banner */}
              <div className="h-64 sm:h-80 rounded-2xl overflow-hidden relative mb-8">
                <img 
                  src={selectedDept.image} 
                  alt={selectedDept.name} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent" />
                <div className="absolute bottom-5 left-5 right-5 text-white flex items-end justify-between">
                  <div>
                    <span className="text-[9px] uppercase font-black text-cyan-400 tracking-widest bg-cyan-950/40 border border-cyan-800/30 px-2 py-0.5 rounded-md">
                      Specialist wing
                    </span>
                    <h2 className="font-display font-extrabold text-2xl sm:text-3xl mt-1.5">{selectedDept.name}</h2>
                  </div>
                  <span className="p-3 bg-white/20 backdrop-blur-md rounded-xl text-white border border-white/20 hidden sm:block">
                    <Icon name={selectedDept.icon} size={24} />
                  </span>
                </div>
              </div>

              {/* Long Description */}
              <div className="text-left mb-8">
                <h3 className="font-display font-bold text-lg text-slate-900 border-b border-slate-100 pb-2 mb-4">
                  Overview of Operations
                </h3>
                <p className="text-sm text-slate-500 leading-relaxed font-normal">
                  {selectedDept.longDescription}
                </p>
              </div>

              {/* Grid: Areas of Specialties & Ward Features */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 text-left">
                
                {/* Clinical Areas */}
                <div>
                  <h4 className="font-display font-bold text-sm text-slate-900 mb-4 uppercase tracking-wider text-cyan-700 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-cyan-600 rounded-full" />
                    <span>Areas of Specialty Focus</span>
                  </h4>
                  <ul className="space-y-2.5 text-xs text-slate-500 font-normal">
                    {selectedDept.specialties.map((spec, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check size={14} className="text-cyan-500 flex-shrink-0 mt-0.5" />
                        <span>{spec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Ward Features */}
                <div>
                  <h4 className="font-display font-bold text-sm text-slate-900 mb-4 uppercase tracking-wider text-cyan-700 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-cyan-600 rounded-full" />
                    <span>In-House Ward Equipment</span>
                  </h4>
                  <ul className="space-y-2.5 text-xs text-slate-500 font-normal">
                    {selectedDept.features.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check size={14} className="text-cyan-500 flex-shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

              </div>

              {/* Department Meta bar */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mt-10">
                <div className="text-left leading-tight">
                  <span className="text-[10px] uppercase font-bold text-slate-450 tracking-wider block">Clinical Chairperson</span>
                  <span className="font-display font-black text-slate-800 text-sm block mt-1">{selectedDept.headOfDept}</span>
                </div>
                
                <button
                  onClick={() => onBookAppointmentWithDept(selectedDept.id)}
                  id={`book-dept-${selectedDept.id}`}
                  className="bg-cyan-600 hover:bg-cyan-700 active:scale-95 text-white font-sans font-bold text-xs tracking-wider uppercase px-5 py-3 rounded-xl transition-all shadow-md shadow-cyan-600/10 flex items-center gap-1.5 self-stretch sm:self-auto justify-center"
                >
                  <Calendar size={14} />
                  <span>Schedule Consultation</span>
                </button>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* Specialty Accreditations footer */}
      <section className="bg-slate-900 text-white/80 py-12 border-t border-slate-800">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <p className="text-xs text-slate-400">
            *All specialty operations at {HOSPITAL_NAME} conform directly to clinical guidelines set by national boards and are certified fully for inpatient surgeries and high-risk pediatric life assistance systems.
          </p>
        </div>
      </section>

    </div>
  );
}
