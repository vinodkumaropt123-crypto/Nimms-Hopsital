/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Users, Calendar, ShoppingBag, ShieldCheck, LogOut, Search, Plus, 
  Trash2, Edit, Check, X, Shield, Lock, LayoutDashboard, HeartPulse,
  TrendingUp, CircleAlert, DollarSign, Activity, FileSpreadsheet, PlusCircle
} from 'lucide-react';
import { DEPARTMENTS_DATA, DOCTORS_DATA } from '../data';

interface SessionUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
}

interface Appointment {
  id: string;
  name: string;
  phone: string;
  department: string;
  doctor: string;
  date: string;
  timeSlot: string;
  notes?: string;
  status: 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled';
  createdAt: string;
}

interface Order {
  id: string;
  patientName: string;
  email: string;
  phone: string;
  packageName: string;
  amount: number;
  status: 'Pending' | 'Paid' | 'Shipped' | 'Cancelled';
  paymentMethod: string;
  date: string;
  createdAt: string;
}

interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'Patient' | 'Doctor' | 'Admin';
  status: 'Active' | 'Suspended';
  createdAt: string;
}

interface AdminPanelProps {
  onBackToWebsite?: () => void;
}

export default function AdminPanel({ onBackToWebsite }: AdminPanelProps) {
  // Authentication state
  const [token, setToken] = useState<string | null>(() => sessionStorage.getItem('nimms_admin_token'));
  const [profile, setProfile] = useState<SessionUser | null>(() => {
    const raw = sessionStorage.getItem('nimms_admin_profile');
    return raw ? JSON.parse(raw) : null;
  });

  const [loginEmail, setLoginEmail] = useState('admin@nimms.com');
  const [loginPassword, setLoginPassword] = useState('nimmsadmin123');
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Core Data models
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [users, setUsers] = useState<User[]>([]);

  // Navigation tabs
  const [activeTab, setActiveTab] = useState<'dashboard' | 'appointments' | 'orders' | 'users'>('dashboard');

  // Search & Filtes
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Loading indicator states
  const [isLoading, setIsLoading] = useState(false);
  const [systemMessage, setSystemMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Modals status & payloads
  const [activeModal, setActiveModal] = useState<'create_appt' | 'edit_appt' | 'create_order' | 'edit_order' | 'create_user' | 'edit_user' | null>(null);
  
  // Selection payloads
  const [selectedAppt, setSelectedAppt] = useState<Appointment | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  // Form states
  const [apptForm, setApptForm] = useState({
    name: '', phone: '', department: DEPARTMENTS_DATA[0].id, 
    doctor: DOCTORS_DATA[0].id, date: '', 
    timeSlot: '09:00 AM - 10:00 AM', notes: '', status: 'Pending' as any
  });

  const [orderForm, setOrderForm] = useState({
    patientName: '', email: '', phone: '', packageName: 'Comprehensive Full-Body Checkup Package',
    amount: 1500, status: 'Pending' as any, paymentMethod: 'UPI (GPay)', date: ''
  });

  const [userForm, setUserForm] = useState({
    name: '', email: '', phone: '', role: 'Patient' as any, status: 'Active' as any, password: ''
  });

  // Display generic feedback for 4 seconds
  const showNotification = (text: string, type: 'success' | 'error' = 'success') => {
    setSystemMessage({ text, type });
    setTimeout(() => setSystemMessage(null), 4000);
  };

  // REST API: Login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsLoggingIn(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail, password: loginPassword })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Authentication denied.');
      }

      sessionStorage.setItem('nimms_admin_token', data.token);
      sessionStorage.setItem('nimms_admin_profile', JSON.stringify(data.profile));

      setToken(data.token);
      setProfile(data.profile);
      showNotification('Signed into management portal with full clearance.', 'success');
    } catch (err: any) {
      setLoginError(err.message);
    } finally {
      setIsLoggingIn(false);
    }
  };

  // REST API: Logout
  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
    } catch (e) {}
    
    sessionStorage.removeItem('nimms_admin_token');
    sessionStorage.removeItem('nimms_admin_profile');
    setToken(null);
    setProfile(null);
    setAppointments([]);
    setOrders([]);
    setUsers([]);
    showNotification('System session destroyed safely.');
  };

  // REST API: Fetch Data
  const fetchAllData = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const headers = { 'Authorization': `Bearer ${token}` };

      // Parallel reads
      const [resAppt, resOrder, resUser] = await Promise.all([
        fetch('/api/appointments', { headers }),
        fetch('/api/orders', { headers }),
        fetch('/api/users', { headers })
      ]);

      if (resAppt.ok) setAppointments(await resAppt.json());
      if (resOrder.ok) setOrders(await resOrder.json());
      if (resUser.ok) setUsers(await resUser.json());
    } catch (err: any) {
      showNotification('Querying database failed: ' + err.message, 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (token) {
      fetchAllData();
    }
  }, [token]);

  // Cleanup selection before opening modals
  const openCreateAppt = () => {
    setApptForm({
      name: '', phone: '', department: DEPARTMENTS_DATA[0].id,
      doctor: DOCTORS_DATA[0].id, date: new Date().toISOString().split('T')[0],
      timeSlot: '09:00 AM - 10:00 AM', notes: '', status: 'Pending'
    });
    setActiveModal('create_appt');
  };

  const openEditAppt = (appt: Appointment) => {
    setSelectedAppt(appt);
    setApptForm({
      name: appt.name,
      phone: appt.phone,
      department: appt.department,
      doctor: appt.doctor,
      date: appt.date,
      timeSlot: appt.timeSlot,
      notes: appt.notes || '',
      status: appt.status
    });
    setActiveModal('edit_appt');
  };

  // REST API: CRUD Operations for Appointments
  const handleApptSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const isEdit = activeModal === 'edit_appt';
      const url = isEdit ? `/api/appointments/${selectedAppt?.id}` : '/api/appointments';
      const method = isEdit ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(apptForm)
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showNotification(isEdit ? 'Clinical appointment record adjusted.' : 'Appointment logged into scheduler queues.');
      setActiveModal(null);
      fetchAllData();
    } catch (err: any) {
      showNotification(err.message, 'error');
    }
  };

  const deleteAppointmentId = async (id: string) => {
    if (!window.confirm(`Purge appointment registry ${id} entirely from index files?`)) return;
    try {
      const res = await fetch(`/api/appointments/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showNotification('Appointment register expunged.');
      fetchAllData();
    } catch (err: any) {
      showNotification(err.message, 'error');
    }
  };

  // CRUD Actions for Patient Invoices / Diagnostic Orders
  const openCreateOrder = () => {
    setOrderForm({
      patientName: '', email: '', phone: '',
      packageName: 'Comprehensive Full-Body Checkup Package',
      amount: 4500, status: 'Pending', paymentMethod: 'UPI (GPay)',
      date: new Date().toISOString().split('T')[0]
    });
    setActiveModal('create_order');
  };

  const openEditOrder = (order: Order) => {
    setSelectedOrder(order);
    setOrderForm({
      patientName: order.patientName,
      email: order.email,
      phone: order.phone,
      packageName: order.packageName,
      amount: order.amount,
      status: order.status,
      paymentMethod: order.paymentMethod,
      date: order.date
    });
    setActiveModal('edit_order');
  };

  const handleOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const isEdit = activeModal === 'edit_order';
      const url = isEdit ? `/api/orders/${selectedOrder?.id}` : '/api/orders';
      const method = isEdit ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(orderForm)
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showNotification(isEdit ? 'Invoice order ticket saved with success.' : 'New invoice order entry committed.');
      setActiveModal(null);
      fetchAllData();
    } catch (err: any) {
      showNotification(err.message, 'error');
    }
  };

  const deleteOrderId = async (id: string) => {
    if (!window.confirm(`Purge billing order ticket ${id} completely from accounting records?`)) return;
    try {
      const res = await fetch(`/api/orders/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showNotification('Invoice record successfully cleared.');
      fetchAllData();
    } catch (err: any) {
      showNotification(err.message, 'error');
    }
  };

  // CRUD Actions for User Accounts Control
  const openCreateUser = () => {
    setUserForm({ name: '', email: '', phone: '', role: 'Patient', status: 'Active', password: '' });
    setActiveModal('create_user');
  };

  const openEditUser = (usr: User) => {
    setSelectedUser(usr);
    setUserForm({
      name: usr.name,
      email: usr.email,
      phone: usr.phone,
      role: usr.role,
      status: usr.status,
      password: '' // empty means no password alteration
    });
    setActiveModal('edit_user');
  };

  const handleUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const isEdit = activeModal === 'edit_user';
      const url = isEdit ? `/api/users/${selectedUser?.id}` : '/api/users';
      const method = isEdit ? 'PUT' : 'POST';

      // Remove password key if empty on edits
      const payload: any = { ...userForm };
      if (isEdit && !payload.password) delete payload.password;

      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showNotification(isEdit ? 'User account registry parameters edited.' : 'New user account registered.');
      setActiveModal(null);
      fetchAllData();
    } catch (err: any) {
      showNotification(err.message, 'error');
    }
  };

  const deleteUserId = async (id: string) => {
    if (id === profile?.id) {
      showNotification('Restricted. You are currently authenticated under this administrator credential profile.', 'error');
      return;
    }
    if (!window.confirm(`Expunge user account records ${id} from database lists?`)) return;
    try {
      const res = await fetch(`/api/users/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showNotification('User account cleared.');
      fetchAllData();
    } catch (err: any) {
      showNotification(err.message, 'error');
    }
  };

  // Filter lists based on query
  const filteredAppointments = appointments.filter(a => {
    const term = searchQuery.toLowerCase();
    const matchSearch = a.name.toLowerCase().includes(term) || a.id.toLowerCase().includes(term) || a.phone.includes(term);
    const matchStatus = statusFilter === 'all' || a.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const filteredOrders = orders.filter(o => {
    const term = searchQuery.toLowerCase();
    const matchSearch = o.patientName.toLowerCase().includes(term) || o.id.toLowerCase().includes(term) || o.packageName.toLowerCase().includes(term);
    const matchStatus = statusFilter === 'all' || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const filteredUsers = users.filter(u => {
    const term = searchQuery.toLowerCase();
    const matchSearch = u.name.toLowerCase().includes(term) || u.email.toLowerCase().includes(term) || u.phone.includes(term);
    const matchStatus = statusFilter === 'all' || u.role === statusFilter || u.status === statusFilter;
    return matchSearch && matchStatus;
  });

  // Calculate Metrics
  const totalRevenue = orders.filter(o => o.status === 'Paid').reduce((acc, o) => acc + o.amount, 0);
  const pendingReservations = appointments.filter(a => a.status === 'Pending').length;
  const activeDoctorsCount = users.filter(u => u.role === 'Doctor' && u.status === 'Active').length;

  // View Loader
  if (!token) {
    return (
      <div className="pt-32 pb-20 min-h-screen bg-slate-950 font-sans text-slate-200 text-left flex items-center justify-center px-4 relative overflow-hidden">
        {/* Abstract background blur */}
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-cyan-600/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-red-600/5 rounded-full blur-[120px]" />

        <div className="max-w-md w-full bg-slate-900 border border-slate-800 p-8 rounded-3xl shadow-2xl relative z-10 animate-scale-up">
          <div className="text-center mb-8">
            <div className="w-12 h-12 bg-cyan-950 border border-cyan-800 rounded-2xl flex items-center justify-center text-cyan-400 mx-auto mb-3 shadow-lg shadow-cyan-600/5">
              <Shield size={24} />
            </div>
            <h2 className="font-display font-black text-2xl tracking-tight text-white">NIMMS Administration</h2>
            <p className="text-slate-400 text-xs mt-1.5 leading-relaxed font-sans">
              Enter secure cryptographic login codes to gain active clearance parameters across clinical schedules and invoice sheets.
            </p>
          </div>

          {loginError && (
            <div className="mb-5 p-3.5 bg-red-950/50 border border-red-900/50 rounded-xl flex items-start gap-2.5 text-xs text-red-300">
              <CircleAlert size={16} className="mt-0.5 flex-shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-[10px] font-extrabold uppercase tracking-widest text-slate-400 mb-1.5">
                Portal Email Coordinator
              </label>
              <input
                type="email"
                required
                className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl focus:border-cyan-500 outline-none text-xs text-white placeholder-slate-600 transition-all font-mono"
                placeholder="admin@nimms.com"
                value={loginEmail}
                onChange={e => setLoginEmail(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-[10px] font-extrabold uppercase tracking-widest text-slate-400 mb-1.5 flex justify-between items-center">
                <span>Access Password</span>
                <span className="text-[9px] text-slate-500 select-none">Safe SHA-256 Hashing</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-3.5 text-slate-650">
                  <Lock size={14} />
                </span>
                <input
                  type="password"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-slate-950 border border-slate-800 rounded-xl focus:border-cyan-500 outline-none text-xs text-white placeholder-slate-600 transition-all font-mono"
                  placeholder="••••••••••••"
                  value={loginPassword}
                  onChange={e => setLoginPassword(e.target.value)}
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full bg-cyan-600 hover:bg-cyan-700 active:scale-[0.99] disabled:bg-cyan-400/50 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg text-xs uppercase tracking-widest flex items-center justify-center gap-2 mt-2"
            >
              {isLoggingIn ? 'Decrypting Clearance...' : 'Authenticate Access'}
            </button>
          </form>

          <div className="mt-6 pt-5 border-t border-slate-800 text-[10px] text-center text-slate-500 leading-normal">
            <p>Master Admin Creds (Automatic seed):</p>
            <p className="font-mono mt-1 text-slate-400">admin@nimms.com / nimmsadmin123</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 min-h-screen text-left font-sans text-slate-800 pt-24 text-[13px] antialiased">
      {/* 1. TOP CONTROL BAR */}
      <div className="bg-white border-b border-slate-100 py-3 relative z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-3">
            <span className="p-2.5 bg-slate-900 rounded-xl text-cyan-400">
              <ShieldCheck size={20} />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-black text-cyan-600 tracking-wider">Administrative Console</span>
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
              </div>
              <h1 className="font-display font-extrabold text-lg text-slate-900 leading-tight">NIMMS Control Hub</h1>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <div className="text-right leading-none hidden md:block">
              <p className="font-bold text-slate-950 text-xs">{profile.name}</p>
              <p className="text-[10px] text-slate-400 font-mono mt-1 pr-0.5">{profile.role} clearance profile</p>
            </div>
            
            {onBackToWebsite && (
              <button
                onClick={onBackToWebsite}
                className="px-3.5 py-2 hover:bg-slate-50 text-slate-700 hover:text-cyan-600 font-bold border border-slate-205 border-slate-200 bg-white active:scale-95 transition-all rounded-xl flex items-center gap-1.5 text-xs text-center justify-center self-stretch sm:self-auto"
              >
                <span>NIMMS Website</span>
              </button>
            )}
            
            <button
              onClick={handleLogout}
              className="px-3.5 py-2 hover:bg-red-50 text-red-650 hover:text-red-700 font-bold border border-red-100 bg-red-50/20 active:scale-95 transition-all rounded-xl flex items-center gap-1.5 text-xs text-center justify-center self-stretch sm:self-auto"
            >
              <LogOut size={14} />
              <span>Sign Off</span>
            </button>
          </div>
        </div>
      </div>

      {/* SYSTEM MESSAGES BADGE */}
      {systemMessage && (
        <div className="fixed top-24 right-6 z-50 animate-scale-up">
          <div className={`p-4 rounded-2xl shadow-2xl border flex items-center gap-3 text-xs leading-relaxed max-w-sm ${
            systemMessage.type === 'success' 
              ? 'bg-emerald-900 border-emerald-800 text-emerald-100' 
              : 'bg-red-950 border-red-900 text-red-200'
          }`}>
            <ShieldCheck size={18} className="flex-shrink-0" />
            <span>{systemMessage.text}</span>
          </div>
        </div>
      )}

      {/* 2. MAIN BENTO GRID & CONTROL LAYOUT */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Navigation Sidebar */}
          <div className="lg:col-span-3 space-y-2 lg:sticky lg:top-28">
            <span className="text-[10px] uppercase font-black text-slate-450 tracking-widest pl-2">Section Index</span>
            <div className="bg-white border border-slate-100 p-3 rounded-2xl shadow-sm space-y-1">
              <button
                onClick={() => { setActiveTab('dashboard'); setSearchQuery(''); }}
                className={`w-full p-3.5 rounded-xl text-left font-bold transition-all flex items-center gap-3 ${
                  activeTab === 'dashboard' ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/10' : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <LayoutDashboard size={16} />
                <span>Executive Overview</span>
              </button>

              <button
                onClick={() => { setActiveTab('appointments'); setSearchQuery(''); setStatusFilter('all'); }}
                className={`w-full p-3.5 rounded-xl text-left font-bold transition-all flex items-center justify-between ${
                  activeTab === 'appointments' ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/10' : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Calendar size={16} />
                  <span>Appointments</span>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-md ${
                  activeTab === 'appointments' ? 'bg-cyan-505 bg-cyan-700 text-white' : 'bg-slate-100 text-slate-500'
                }`}>
                  {appointments.length}
                </span>
              </button>

              <button
                onClick={() => { setActiveTab('orders'); setSearchQuery(''); setStatusFilter('all'); }}
                className={`w-full p-3.5 rounded-xl text-left font-bold transition-all flex items-center justify-between ${
                  activeTab === 'orders' ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/10' : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <ShoppingBag size={16} />
                  <span>Orders & Invoices</span>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-md ${
                  activeTab === 'orders' ? 'bg-cyan-700 text-white' : 'bg-slate-100 text-slate-500'
                }`}>
                  {orders.length}
                </span>
              </button>

              <button
                onClick={() => { setActiveTab('users'); setSearchQuery(''); setStatusFilter('all'); }}
                className={`w-full p-3.5 rounded-xl text-left font-bold transition-all flex items-center justify-between ${
                  activeTab === 'users' ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/10' : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Users size={16} />
                  <span>Credentials Board</span>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-md ${
                  activeTab === 'users' ? 'bg-cyan-700 text-white' : 'bg-slate-100 text-slate-500'
                }`}>
                  {users.length}
                </span>
              </button>
            </div>

            <div className="bg-slate-900 border border-slate-800 text-white p-5 rounded-2xl shadow-xl">
              <span className="text-[9px] uppercase font-bold tracking-widest text-cyan-400">Database Directives</span>
              <h4 className="font-display font-bold text-slate-100 text-xs mt-1">Hostinger MySQL Setup</h4>
              <p className="text-[10.5px] text-slate-400 mt-2 leading-relaxed">
                A structured database blueprint file is written in the environment root directory at <span className="font-mono text-cyan-300">/schema.sql</span>. Import that output directly inside PHPMyAdmin SQL console on Hostinger.
              </p>
            </div>
          </div>

          {/* Core Content Area */}
          <div className="lg:col-span-9 bg-white border border-slate-100 rounded-3xl p-6 md:p-8 shadow-sm">
            
            {/* TAB: EXECUTIVE DASHBOARD */}
            {activeTab === 'dashboard' && (
              <div className="space-y-8 animate-fade-in text-left">
                <div>
                  <h2 className="font-display font-black text-slate-900 text-xl">Healthcare Executive Summary</h2>
                  <p className="text-slate-500 text-xs mt-1 leading-normal">Comprehensive statistical overview of NIMMS clinic operations.</p>
                </div>

                {/* KPI Metrics */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  {/* KPI 1 */}
                  <div className="p-5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-4">
                    <span className="p-3 bg-cyan-50 border border-cyan-100 rounded-xl text-cyan-600">
                      <DollarSign size={20} />
                    </span>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Total Billing Turnover</span>
                      <p className="font-display font-black text-[19px] text-slate-900 mt-0.5">₹{totalRevenue.toLocaleString()}</p>
                    </div>
                  </div>

                  {/* KPI 2 */}
                  <div className="p-5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-4">
                    <span className="p-3 bg-amber-50 border border-amber-100 rounded-xl text-amber-600">
                      <Calendar size={20} className="animate-pulse" />
                    </span>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Pending Reservations</span>
                      <p className="font-display font-black text-[19px] text-slate-900 mt-0.5">{pendingReservations} Tickets</p>
                    </div>
                  </div>

                  {/* KPI 3 */}
                  <div className="p-5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-4">
                    <span className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl text-indigo-600">
                      <Activity size={20} />
                    </span>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Active Specialist Chairs</span>
                      <p className="font-display font-black text-[19px] text-slate-900 mt-0.5">{activeDoctorsCount} Attenders</p>
                    </div>
                  </div>
                </div>

                {/* Sub panels */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                  {/* Left Recent Registries */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                      <h3 className="font-display font-bold text-sm text-slate-900">Recent Waiting Queue</h3>
                      <button onClick={() => setActiveTab('appointments')} className="text-cyan-600 hover:underline text-[11px] font-bold">Manage All →</button>
                    </div>

                    <div className="space-y-2.5">
                      {appointments.slice(0, 3).map(appt => (
                        <div key={appt.id} className="p-4 bg-slate-50/50 border border-slate-100/80 rounded-xl flex items-center justify-between text-left">
                          <div className="leading-tight">
                            <span className="font-mono text-[10px] font-bold text-cyan-650 text-cyan-600">{appt.id}</span>
                            <h4 className="font-bold text-slate-800 text-xs mt-0.5">{appt.name}</h4>
                            <p className="text-[10px] text-slate-400 mt-0.5">{appt.date} at {appt.timeSlot.split(' - ')[0]}</p>
                          </div>
                          <span className={`px-2.5 py-0.5 rounded-full font-sans font-bold text-[9px] ${
                            appt.status === 'Confirmed' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                            appt.status === 'Cancelled' ? 'bg-red-50 text-red-600 border border-red-100' :
                            appt.status === 'Completed' ? 'bg-slate-100 text-slate-500' :
                            'bg-amber-50 text-amber-600 border border-amber-100'
                          }`}>
                            {appt.status}
                          </span>
                        </div>
                      ))}
                      {appointments.length === 0 && (
                        <p className="text-[11px] text-slate-400 text-center py-6">No queue records active.</p>
                      )}
                    </div>
                  </div>

                  {/* Right Recent Invoices */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                      <h3 className="font-display font-bold text-sm text-slate-900">Recent Pharmacy & Lab Sales</h3>
                      <button onClick={() => setActiveTab('orders')} className="text-cyan-600 hover:underline text-[11px] font-bold">Accounting →</button>
                    </div>

                    <div className="space-y-2.5 font-sans text-xs text-slate-500">
                      {orders.slice(0, 3).map(ord => (
                        <div key={ord.id} className="p-4 bg-slate-50/50 border border-slate-100/80 rounded-xl flex items-center justify-between">
                          <div className="leading-tight text-left">
                            <span className="font-mono text-[10px] font-bold text-indigo-500">{ord.id}</span>
                            <h4 className="font-bold text-slate-800 text-xs mt-0.5">{ord.patientName}</h4>
                            <p className="text-[10px] text-slate-400 mt-0.5 truncate max-w-[150px]">{ord.packageName}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-display font-black text-slate-900">₹{ord.amount}</p>
                            <span className={`text-[9.5px] font-bold ${ord.status === 'Paid' ? 'text-emerald-600' : 'text-amber-500'}`}>{ord.status}</span>
                          </div>
                        </div>
                      ))}
                      {orders.length === 0 && (
                        <p className="text-[11px] text-slate-400 text-center py-6">No orders logs recorded.</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Security attestation banner */}
                <div className="p-5 rounded-2xl bg-zinc-50 border border-zinc-150 flex gap-4 mt-8 items-start">
                  <div className="p-2.5 bg-slate-900 text-emerald-400 rounded-xl">
                    <ShieldCheck size={20} />
                  </div>
                  <div>
                    <h4 className="font-display font-bold text-slate-900 text-sm">System Audit Logging Active</h4>
                    <p className="text-xs text-slate-450 leading-relaxed font-normal mt-1">
                      Every registration dispatch, status adjustment, or administrative database delete action is logged under secure system protocols immediately. Access IP Address is mapped to safeguard private patient information registers.
                    </p>
                  </div>
                </div>

              </div>
            )}

            {/* TAB: APPOINTMENTS */}
            {activeTab === 'appointments' && (
              <div className="space-y-6 animate-fade-in">
                
                {/* Section header */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="text-left">
                    <h2 className="font-display font-black text-slate-900 text-lg leading-none">Schedule Operations</h2>
                    <p className="text-slate-500 text-xs mt-1">Manage and update clinical OPD reservation slots.</p>
                  </div>

                  <button
                    onClick={openCreateAppt}
                    className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs tracking-wider uppercase px-4.5 py-3 rounded-xl transition-all shadow-md flex items-center gap-1.5 focus:outline-none"
                  >
                    <PlusCircle size={15} />
                    <span>Log Appointment</span>
                  </button>
                </div>

                {/* Filter and search banner */}
                <div className="flex flex-col sm:flex-row gap-4 items-center justify-between border-y border-slate-100 py-4">
                  {/* Search box */}
                  <div className="relative w-full sm:max-w-xs">
                    <span className="absolute left-3 top-3 text-slate-400">
                      <Search size={14} />
                    </span>
                    <input
                      type="text"
                      className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                      placeholder="Search patient, phone, ID..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                    />
                  </div>

                  {/* Status filter tray */}
                  <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
                    {['all', 'Pending', 'Confirmed', 'Completed', 'Cancelled'].map(status => (
                      <button
                        key={status}
                        onClick={() => setStatusFilter(status)}
                        className={`px-3 py-1.5 rounded-full font-semibold text-[11px] transition-all border ${
                          statusFilter === status 
                            ? 'bg-slate-900 text-white border-slate-900 shadow-sm' 
                            : 'bg-white text-slate-500 border-slate-200/60 hover:text-cyan-600 hover:bg-slate-50'
                        }`}
                      >
                        {status === 'all' ? 'All Status' : status}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Direct list display */}
                <div className="overflow-x-auto border border-slate-150 rounded-2xl">
                  <table className="w-full text-left border-collapse font-sans text-xs select-none">
                    <thead>
                      <tr className="bg-slate-50 text-slate-505 font-bold uppercase tracking-wider text-[10px] border-b border-slate-150">
                        <th className="p-4">Ticket ID</th>
                        <th className="p-4">Patient Name & Contact</th>
                        <th className="p-4">Clinical Specialty</th>
                        <th className="p-4">Preferred Date</th>
                        <th className="p-4">Status</th>
                        <th className="p-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredAppointments.map(appt => {
                        const dept = DEPARTMENTS_DATA.find(d => d.id === appt.department);
                        return (
                          <tr key={appt.id} className="hover:bg-slate-50/55 transition-colors font-sans">
                            <td className="p-4 font-mono font-bold text-cyan-600 block sm:table-cell">{appt.id}</td>
                            <td className="p-4">
                              <p className="font-bold text-slate-900 text-sm leading-none">{appt.name}</p>
                              <p className="text-[10px] text-slate-400 font-mono mt-1">{appt.phone}</p>
                            </td>
                            <td className="p-4">
                              <p className="font-medium text-slate-800">{dept?.name || appt.department}</p>
                              {appt.notes && <p className="text-[10px] text-slate-450 truncate max-w-[150px] mt-0.5 italic">"{appt.notes}"</p>}
                            </td>
                            <td className="p-4">
                              <p className="font-semibold text-slate-800">{appt.date}</p>
                              <p className="text-[9px] text-slate-400 mt-1">{appt.timeSlot.split(' - ')[0]}</p>
                            </td>
                            <td className="p-4">
                              <span className={`px-2.5 py-0.5 rounded-full font-sans font-bold text-[9px] ${
                                appt.status === 'Confirmed' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                                appt.status === 'Cancelled' ? 'bg-red-50 text-red-650 border border-red-100' :
                                appt.status === 'Completed' ? 'bg-slate-100 text-slate-500' :
                                'bg-amber-50 text-amber-600 border border-amber-100'
                              }`}>
                                {appt.status}
                              </span>
                            </td>
                            <td className="p-4 text-right">
                              <div className="inline-flex gap-2 justify-end">
                                <button
                                  onClick={() => openEditAppt(appt)}
                                  className="p-1.5 text-slate-500 hover:text-cyan-600 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-all focus:outline-none"
                                  title="Edit Entry"
                                >
                                  <Edit size={13} />
                                </button>
                                <button
                                  onClick={() => deleteAppointmentId(appt.id)}
                                  className="p-1.5 text-slate-500 hover:text-red-600 bg-slate-50 hover:bg-red-50 rounded-lg border border-slate-200 transition-all focus:outline-none"
                                  title="Delete Entry"
                                >
                                  <Trash2 size={13} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                      {filteredAppointments.length === 0 && (
                        <tr>
                          <td colSpan={6} className="p-12 text-center text-slate-400 font-sans text-xs">
                            No appointment queue entries map to search filters.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

              </div>
            )}

            {/* TAB: ORDERS & INVOICES */}
            {activeTab === 'orders' && (
              <div className="space-y-6 animate-fade-in">
                
                {/* Section header */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="text-left">
                    <h2 className="font-display font-black text-slate-900 text-lg leading-none">Diagnostic & Pharmacy Accounting</h2>
                    <p className="text-slate-500 text-xs mt-1">Register payments and manage wellness package orders.</p>
                  </div>

                  <button
                    onClick={openCreateOrder}
                    className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs tracking-wider uppercase px-4.5 py-3 rounded-xl transition-all shadow-md flex items-center gap-1.5 focus:outline-none"
                  >
                    <PlusCircle size={15} />
                    <span>Create Invoice Log</span>
                  </button>
                </div>

                {/* Filter and search banner */}
                <div className="flex flex-col sm:flex-row gap-4 items-center justify-between border-y border-slate-100 py-4">
                  {/* Search box */}
                  <div className="relative w-full sm:max-w-xs">
                    <span className="absolute left-3 top-3 text-slate-400">
                      <Search size={14} />
                    </span>
                    <input
                      type="text"
                      className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                      placeholder="Search patient, billing item, ID..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                    />
                  </div>

                  {/* Status filter tray */}
                  <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
                    {['all', 'Pending', 'Paid', 'Shipped', 'Cancelled'].map(status => (
                      <button
                        key={status}
                        onClick={() => setStatusFilter(status)}
                        className={`px-3 py-1.5 rounded-full font-semibold text-[11px] transition-all border ${
                          statusFilter === status 
                            ? 'bg-slate-900 text-white border-slate-900 shadow-sm' 
                            : 'bg-white text-slate-500 border-slate-200/60 hover:text-cyan-600 hover:bg-slate-50'
                        }`}
                      >
                        {status === 'all' ? 'All Ledger' : status}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Direct list display */}
                <div className="overflow-x-auto border border-slate-150 rounded-2xl">
                  <table className="w-full text-left border-collapse font-sans text-xs select-none">
                    <thead>
                      <tr className="bg-slate-50 text-slate-505 font-bold uppercase tracking-wider text-[10px] border-b border-slate-150">
                        <th className="p-4">Invoice ID</th>
                        <th className="p-4">Recipient Patient</th>
                        <th className="p-4">Assembled Package Treatment</th>
                        <th className="p-4">Rate Fee</th>
                        <th className="p-4">Settlement Status</th>
                        <th className="p-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredOrders.map(ord => (
                        <tr key={ord.id} className="hover:bg-slate-50/55 transition-colors font-sans">
                          <td className="p-4 font-mono font-bold text-indigo-500">{ord.id}</td>
                          <td className="p-4">
                            <p className="font-bold text-slate-900 text-sm leading-none">{ord.patientName}</p>
                            <p className="text-[10px] text-slate-450 font-mono mt-1">{ord.email}</p>
                          </td>
                          <td className="p-4">
                            <p className="font-semibold text-slate-800 leading-normal">{ord.packageName}</p>
                            <p className="text-[10px] text-slate-400 mt-1 font-sans">{ord.paymentMethod} on {ord.date}</p>
                          </td>
                          <td className="p-4">
                            <span className="font-display font-black text-slate-900 text-sm">₹{ord.amount.toLocaleString()}</span>
                          </td>
                          <td className="p-4">
                            <span className={`px-2.5 py-0.5 rounded-full font-sans font-bold text-[9px] ${
                              ord.status === 'Paid' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                              ord.status === 'Cancelled' ? 'bg-red-50 text-red-650 border border-red-100' :
                              ord.status === 'Shipped' ? 'bg-blue-50 text-blue-600 border border-blue-100' :
                              'bg-amber-50 text-amber-600 border border-amber-100'
                            }`}>
                              {ord.status}
                            </span>
                          </td>
                          <td className="p-4 text-right">
                            <div className="inline-flex gap-2 justify-end">
                              <button
                                onClick={() => openEditOrder(ord)}
                                className="p-1.5 text-slate-500 hover:text-cyan-600 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-all focus:outline-none"
                                title="Edit Ledger"
                              >
                                <Edit size={13} />
                              </button>
                              <button
                                onClick={() => deleteOrderId(ord.id)}
                                className="p-1.5 text-slate-500 hover:text-red-600 bg-slate-50 hover:bg-red-50 rounded-lg border border-slate-200 transition-all focus:outline-none"
                                title="Delete Ledger"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                      {filteredOrders.length === 0 && (
                        <tr>
                          <td colSpan={6} className="p-12 text-center text-slate-400 font-sans text-xs">
                            No ledger invoice entries match search queries.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

              </div>
            )}

            {/* TAB: USERS MANAGEMENT */}
            {activeTab === 'users' && (
              <div className="space-y-6 animate-fade-in">
                
                {/* Section header */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="text-left">
                    <h2 className="font-display font-black text-slate-900 text-lg leading-none">Security & Role Credentials board</h2>
                    <p className="text-slate-500 text-xs mt-1">Manage staff, diagnostic doctors, and administrator accounts.</p>
                  </div>

                  <button
                    onClick={openCreateUser}
                    className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs tracking-wider uppercase px-4.5 py-3 rounded-xl transition-all shadow-md flex items-center gap-1.5 focus:outline-none"
                  >
                    <PlusCircle size={15} />
                    <span>Create User Profile</span>
                  </button>
                </div>

                {/* Filter and search banner */}
                <div className="flex flex-col sm:flex-row gap-4 items-center justify-between border-y border-slate-100 py-4">
                  {/* Search box */}
                  <div className="relative w-full sm:max-w-xs">
                    <span className="absolute left-3 top-3 text-slate-400">
                      <Search size={14} />
                    </span>
                    <input
                      type="text"
                      className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                      placeholder="Search accounts name, email, contact..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                    />
                  </div>

                  {/* Status filter tray */}
                  <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
                    {['all', 'Admin', 'Doctor', 'Patient', 'Active', 'Suspended'].map(category => (
                      <button
                        key={category}
                        onClick={() => setStatusFilter(category)}
                        className={`px-3 py-1.5 rounded-full font-semibold text-[11px] transition-all border ${
                          statusFilter === category 
                            ? 'bg-slate-900 text-white border-slate-900 shadow-sm' 
                            : 'bg-white text-slate-500 border-slate-200/60 hover:text-cyan-600 hover:bg-slate-50'
                        }`}
                      >
                        {category === 'all' ? 'All Roles & Status' : category}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Direct list display */}
                <div className="overflow-x-auto border border-slate-150 rounded-2xl">
                  <table className="w-full text-left border-collapse font-sans text-xs select-none">
                    <thead>
                      <tr className="bg-slate-50 text-slate-505 font-bold uppercase tracking-wider text-[10px] border-b border-slate-150">
                        <th className="p-4">Profile ID</th>
                        <th className="p-4">Display Name & Coordinator Contact</th>
                        <th className="p-4">Primary Email Coordinates</th>
                        <th className="p-4">Access Authority Role</th>
                        <th className="p-4">Account status</th>
                        <th className="p-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredUsers.map(usr => (
                        <tr key={usr.id} className="hover:bg-slate-50/55 transition-colors font-sans">
                          <td className="p-4 font-mono font-bold text-slate-500">{usr.id}</td>
                          <td className="p-4">
                            <p className="font-bold text-slate-900 text-sm leading-none">{usr.name}</p>
                            <p className="text-[10px] text-slate-400 font-mono mt-1">{usr.phone}</p>
                          </td>
                          <td className="p-4">
                            <span className="font-mono text-slate-700">{usr.email}</span>
                          </td>
                          <td className="p-4">
                            <span className={`px-2.5 py-0.5 rounded-md font-sans font-bold text-[10px] ${
                              usr.role === 'Admin' ? 'bg-slate-900 text-cyan-400 font-extrabold shadow-inner' :
                              usr.role === 'Doctor' ? 'bg-cyan-50 text-cyan-600' : 'bg-slate-105 bg-slate-50 text-slate-600'
                            }`}>
                              {usr.role}
                            </span>
                          </td>
                          <td className="p-4">
                            <span className={`inline-flex items-center gap-1 text-[10px] font-bold ${
                              usr.status === 'Active' ? 'text-emerald-600' : 'text-red-500'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${usr.status === 'Active' ? 'bg-emerald-500' : 'bg-red-500'}`} />
                              <span>{usr.status}</span>
                            </span>
                          </td>
                          <td className="p-4 text-right">
                            <div className="inline-flex gap-2 justify-end">
                              <button
                                onClick={() => openEditUser(usr)}
                                className="p-1.5 text-slate-500 hover:text-cyan-600 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-all focus:outline-none"
                                title="Edit User"
                              >
                                <Edit size={13} />
                              </button>
                              <button
                                onClick={() => deleteUserId(usr.id)}
                                className="p-1.5 text-slate-500 hover:text-red-600 bg-slate-50 hover:bg-red-50 rounded-lg border border-slate-200 transition-all focus:outline-none"
                                title="Delete User"
                                disabled={usr.id === 'user-admin'}
                              >
                                <Trash2 size={13} className={usr.id === 'user-admin' ? 'opacity-20 cursor-not-allowed' : ''} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                      {filteredUsers.length === 0 && (
                        <tr>
                          <td colSpan={6} className="p-12 text-center text-slate-400 font-sans text-xs">
                            No credentials directory entries mapping search queries.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

              </div>
            )}

          </div>

        </div>
      </div>

      {/* =====================================================================
          MANAGEMENT POPUP EDIT/CREATE MODALS (Unified CSS animations)
          ===================================================================== */}
      {activeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 md:p-8 animate-fade-in">
          <div className="bg-white rounded-3xl overflow-hidden max-w-lg w-full shadow-2xl border border-slate-100 relative animate-scale-up text-slate-800">
            
            {/* Close Button */}
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-all z-10 border border-slate-200"
            >
              <X size={15} />
            </button>

            {/* Modal header banner */}
            <div className="bg-slate-900 p-6 text-white text-left">
              <span className="text-[9px] uppercase font-extrabold text-cyan-400 tracking-widest pl-0.5">Database Dispatch Registry</span>
              <h3 className="font-display font-black text-lg mt-1 text-white">
                {activeModal === 'create_appt' && 'Schedule Direct OPD Session'}
                {activeModal === 'edit_appt' && `Adjust Appointment ${selectedAppt?.id}`}
                {activeModal === 'create_order' && 'Log Manual Pharmacy/Lab Invoice'}
                {activeModal === 'edit_order' && `Update Invoice Ledger ${selectedOrder?.id}`}
                {activeModal === 'create_user' && 'Add Secure Register Account'}
                {activeModal === 'edit_user' && `Update Profile Parameters ${selectedUser?.id}`}
              </h3>
            </div>

            {/* Modal Body Scroll Container */}
            <div className="p-6 max-h-[75vh] overflow-y-auto text-left">
              
              {/* FORM SYSTEM: APPOINTMENTS */}
              {(activeModal === 'create_appt' || activeModal === 'edit_appt') && (
                <form onSubmit={handleApptSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-550 mb-1">Patient Full Name</label>
                    <input
                      type="text" required
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                      value={apptForm.name}
                      onChange={e => setApptForm(p => ({ ...p, name: e.target.value }))}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Contact Phone</label>
                      <input
                        type="tel" required
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={apptForm.phone}
                        onChange={e => setApptForm(p => ({ ...p, phone: e.target.value }))}
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Status Type</label>
                      <select
                        className="w-full px-2.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={apptForm.status}
                        onChange={e => setApptForm(p => ({ ...p, status: e.target.value as any }))}
                      >
                        <option value="Pending">Pending Validation</option>
                        <option value="Confirmed">Confirmed Booked</option>
                        <option value="Completed">Completed Treatment</option>
                        <option value="Cancelled">Cancelled/Postponed</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Specialty Specialty</label>
                      <select
                        className="w-full px-2.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={apptForm.department}
                        onChange={e => setApptForm(p => ({ ...p, department: e.target.value }))}
                      >
                        {DEPARTMENTS_DATA.map(d => (
                          <option key={d.id} value={d.id}>{d.name}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Consulting Physician</label>
                      <select
                        className="w-full px-2.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={apptForm.doctor}
                        onChange={e => setApptForm(p => ({ ...p, doctor: e.target.value }))}
                      >
                        {DOCTORS_DATA.map(d => (
                          <option key={d.id} value={d.id}>{d.name} ({d.role.split(' ')[0]})</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Preferred Date</label>
                      <input
                        type="date" required
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={apptForm.date}
                        onChange={e => setApptForm(p => ({ ...p, date: e.target.value }))}
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Time Block window</label>
                      <select
                        className="w-full px-2.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={apptForm.timeSlot}
                        onChange={e => setApptForm(p => ({ ...p, timeSlot: e.target.value }))}
                      >
                        <option value="09:00 AM - 10:00 AM">09:00 AM - 10:00 AM</option>
                        <option value="10:00 AM - 11:00 AM">10:00 AM - 11:00 AM</option>
                        <option value="11:00 AM - 12:00 PM">11:00 AM - 12:00 PM</option>
                        <option value="12:00 PM - 01:00 PM">12:00 PM - 01:00 PM</option>
                        <option value="02:00 PM - 03:00 PM">02:00 PM - 03:00 PM</option>
                        <option value="03:00 PM - 04:00 PM">03:00 PM - 04:00 PM</option>
                        <option value="04:00 PM - 05:00 PM">04:00 PM - 05:00 PM</option>
                        <option value="05:00 PM - 06:00 PM">05:00 PM - 06:00 PM</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-550 mb-1">Health Remarks / Diagnostics Notes</label>
                    <textarea
                      rows={2}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs resize-none"
                      placeholder="Symptoms, history or checkup instructions..."
                      value={apptForm.notes}
                      onChange={e => setApptForm(p => ({ ...p, notes: e.target.value }))}
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-md text-xs uppercase tracking-widest mt-4"
                  >
                    Commit Appointment Record
                  </button>
                </form>
              )}

              {/* FORM SYSTEM: ORDERS */}
              {(activeModal === 'create_order' || activeModal === 'edit_order') && (
                <form onSubmit={handleOrderSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-550 mb-1">Receipt Patient Name</label>
                    <input
                      type="text" required
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                      value={orderForm.patientName}
                      onChange={e => setOrderForm(p => ({ ...p, patientName: e.target.value }))}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Coordinate Email</label>
                      <input
                        type="email" required
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs font-mono"
                        value={orderForm.email}
                        onChange={e => setOrderForm(p => ({ ...p, email: e.target.value }))}
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Contact Mobile</label>
                      <input
                        type="tel"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={orderForm.phone}
                        onChange={e => setOrderForm(p => ({ ...p, phone: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-550 mb-1">Bought Diagnostic / Treatment Package Item</label>
                    <input
                      type="text" required
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                      value={orderForm.packageName}
                      onChange={e => setOrderForm(p => ({ ...p, packageName: e.target.value }))}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Assessed Fee Pricing (INR)</label>
                      <input
                        type="number" required
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs font-bold font-mono"
                        value={orderForm.amount}
                        onChange={e => setOrderForm(p => ({ ...p, amount: Number(e.target.value) }))}
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Payment Method</label>
                      <select
                        className="w-full px-2.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={orderForm.paymentMethod}
                        onChange={e => setOrderForm(p => ({ ...p, paymentMethod: e.target.value }))}
                      >
                        <option value="UPI (GPay)">UPI (GPay)</option>
                        <option value="UPI (PhonePe)">UPI (PhonePe)</option>
                        <option value="Credit Card (Razorpay)">Credit Card (Razorpay)</option>
                        <option value="Net Banking (HDFC)">Net Banking (HDFC)</option>
                        <option value="Inpatient Admission Cash Desk">Inpatient Admission Cash Desk</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Acquisition Date</label>
                      <input
                        type="date"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={orderForm.date}
                        onChange={e => setOrderForm(p => ({ ...p, date: e.target.value }))}
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Acquisition status</label>
                      <select
                        className="w-full px-2.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={orderForm.status}
                        onChange={e => setOrderForm(p => ({ ...p, status: e.target.value as any }))}
                      >
                        <option value="Pending">Pending Payment</option>
                        <option value="Paid font-bold text-emerald-600">Settled Paid</option>
                        <option value="Shipped">Dispatched / Shipped</option>
                        <option value="Cancelled">Cancelled / Refunded</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-md text-xs uppercase tracking-widest mt-4"
                  >
                    Commit Invoice Ledger Entry
                  </button>
                </form>
              )}

              {/* FORM SYSTEM: SECURE USERS */}
              {(activeModal === 'create_user' || activeModal === 'edit_user') && (
                <form onSubmit={handleUserSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-550 mb-1">Display Profile Name</label>
                    <input
                      type="text" required
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                      value={userForm.name}
                      onChange={e => setUserForm(p => ({ ...p, name: e.target.value }))}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Registered Email Coordinates</label>
                      <input
                        type="email" required
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-205 border-slate-200 focus:bg-white outline-none rounded-xl text-xs font-mono"
                        value={userForm.email}
                        onChange={e => setUserForm(p => ({ ...p, email: e.target.value }))}
                        disabled={activeModal === 'edit_user'} // Safety check: do not rename primary login email context easily
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Mobile number</label>
                      <input
                        type="tel"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={userForm.phone}
                        onChange={e => setUserForm(p => ({ ...p, phone: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Authority clearance level</label>
                      <select
                        className="w-full px-2.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={userForm.role}
                        onChange={e => setUserForm(p => ({ ...p, role: e.target.value as any }))}
                      >
                        <option value="Patient">Patient / Customer</option>
                        <option value="Doctor">Clinic Doctor Specialty</option>
                        <option value="Admin">Master Admin Coordinator</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-550 mb-1">Account System Status</label>
                      <select
                        className="w-full px-2.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs"
                        value={userForm.status}
                        onChange={e => setUserForm(p => ({ ...p, status: e.target.value as any }))}
                      >
                        <option value="Active">Active Operational</option>
                        <option value="Suspended">Suspended / Revoked Access</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-550 mb-1">
                      {activeModal === 'edit_user' ? 'Reset Account Password (leave empty to retain old password)' : 'Define Secure Password'}
                    </label>
                    <input
                      type="password"
                      required={activeModal === 'create_user'}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white outline-none rounded-xl text-xs font-mono"
                      placeholder={activeModal === 'edit_user' ? '••••••••••••' : 'Enter access password'}
                      value={userForm.password}
                      onChange={e => setUserForm(p => ({ ...p, password: e.target.value }))}
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-md text-xs uppercase tracking-widest mt-4"
                  >
                    Commit User Account parameters
                  </button>
                </form>
              )}

            </div>

          </div>
        </div>
      )}

    </div>
  );
}
