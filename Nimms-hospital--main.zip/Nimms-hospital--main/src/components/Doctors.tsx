/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DOCTORS_DATA, HOSPITAL_NAME } from '../data';
import { Star, ShieldCheck, HeartPulse, GraduationCap, Calendar, Clock, Sparkles } from 'lucide-react';

interface DoctorsProps {
  onBookAppointmentWithDoc: (doctorId: string, deptId: string) => void;
}

export default function Doctors({ onBookAppointmentWithDoc }: DoctorsProps) {
  const [selectedSpecialtyFilter, setSelectedSpecialtyFilter] = useState('all');

  const specialties = [
    { id: 'all', name: 'All Specializations' },
    { id: 'general-medicine', name: 'General Medicine' },
    { id: 'pediatrics', name: 'Pediatrics' },
    { id: 'orthopedics', name: 'Orthopedics' },
    { id: 'gynecology', name: 'Gynecology' },
    { id: 'surgery', name: 'Surgery' },
    { id: 'emergency-care', name: 'Emergency Care' }
  ];

  const filteredDoctors = selectedSpecialtyFilter === 'all'
    ? DOCTORS_DATA
    : DOCTORS_DATA.filter(doc => doc.specialtyId === selectedSpecialtyFilter);

  return (
    <div className="font-sans text-slate-800 antialiased pt-24 text-left">
      
      {/* Visual Header */}
      <section className="bg-slate-900 text-white relative py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          <img 
            src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=1200" 
            alt="NIMMS Doctors Team" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/95 to-transparent" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-cyan-400">Award-Winning Medical Board</span>
          <h1 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl mt-2 text-white">Our Senior Clinical Experts</h1>
          <p className="text-slate-350 mt-3 max-w-2xl text-sm leading-relaxed">
            Consisting of board-certified MDs, senior surgeons, and fellows returning from world-class healthcare centers.
          </p>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-12 bg-slate-50 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-left w-full md:w-auto">
            <h3 className="font-display font-bold text-slate-950 text-[15px] flex items-center gap-1.5 leading-none">
              <Sparkles size={16} className="text-cyan-500 animate-pulse" />
              <span>Filter Clinic Specialties</span>
            </h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">Select a specialty to list attending clinical chairs.</p>
          </div>
          
          {/* Scrollable button tray */}
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            {specialties.map((spec) => {
              const isSelected = spec.id === selectedSpecialtyFilter;
              return (
                <button
                  key={spec.id}
                  onClick={() => setSelectedSpecialtyFilter(spec.id)}
                  id={`filter-doc-${spec.id}`}
                  className={`px-4.5 py-2 rounded-full font-sans font-semibold text-xs transition-all ${
                    isSelected 
                      ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/10' 
                      : 'bg-white text-slate-600 hover:text-cyan-600 border border-slate-200/50 hover:bg-slate-50'
                  }`}
                >
                  {spec.name}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Doctors Profiles Board */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredDoctors.map((doc) => (
              <div 
                key={doc.id} 
                className="bg-white border border-slate-100 rounded-3xl overflow-hidden shadow-sm hover:shadow-xl hover:scale-[1.01] transition-all duration-300 flex flex-col text-left group"
              >
                {/* Photo box */}
                <div className="h-64 sm:h-72 overflow-hidden relative bg-slate-100 select-none">
                  <img 
                    src={doc.image} 
                    alt={doc.name} 
                    className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/50 via-transparent to-transparent" />
                  
                  {/* Dynamic Experience Badge */}
                  <span className="absolute top-4 left-4 bg-slate-900/70 backdrop-blur-sm border border-slate-700/50 text-cyan-400 text-[10px] uppercase font-bold tracking-widest px-3 py-1 rounded-md">
                    {doc.experience.split(' ')[0]} Clinical Experience
                  </span>

                  {/* Rating Badge */}
                  <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm px-2.5 py-1 rounded-lg flex items-center gap-1 shadow-md text-slate-800 text-xs font-bold">
                    <Star size={13} fill="currentColor" className="text-amber-500" />
                    <span>{doc.rating}</span>
                    <span className="text-slate-400 text-[10px] font-normal">({doc.reviewsCount})</span>
                  </div>
                </div>

                {/* Profile Meta card */}
                <div className="p-6 flex-grow flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-cyan-600 block">
                      {doc.specialtyName}
                    </span>
                    <h3 className="font-display font-black text-slate-900 text-xl mt-1 leading-snug">
                      {doc.name}
                    </h3>
                    <p className="text-xs text-slate-400 font-bold tracking-tight uppercase leading-none mt-0.5 mb-4">
                      {doc.role}
                    </p>

                    <div className="space-y-2.5 mt-4 pt-4 border-t border-slate-50 text-xs text-slate-500 font-normal">
                      <div className="flex items-start gap-2">
                        <GraduationCap size={15} className="text-slate-400 mt-0.5 flex-shrink-0" />
                        <span>{doc.education}</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Clock size={14} className="text-slate-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="font-bold text-slate-600 uppercase text-[9px] tracking-wider mb-0.5">Consultation Slots:</p>
                          <p className="font-sans text-xs">{doc.consultationHours}</p>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-slate-500 leading-relaxed font-normal mt-5 bg-slate-50 p-3 rounded-xl border border-slate-100">
                      {doc.about}
                    </p>
                  </div>

                  <div className="mt-8 pt-4 border-t border-slate-50 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-1 text-emerald-600 text-[10px] font-bold tracking-tight bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                      <ShieldCheck size={12} />
                      <span>verified profile</span>
                    </div>
                    
                    <button
                      onClick={() => onBookAppointmentWithDoc(doc.id, doc.specialtyId)}
                      id={`book-doc-${doc.id}`}
                      className="bg-cyan-600 hover:bg-cyan-700 active:scale-95 text-white font-sans font-bold text-xs tracking-wider uppercase px-4.5 py-2.5 rounded-xl transition-all shadow-md shadow-cyan-600/10 flex items-center gap-1"
                    >
                      <Calendar size={13} />
                      <span>Book Slot</span>
                    </button>
                  </div>
                </div>

              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Trust seal banner */}
      <section className="bg-slate-900 text-white py-16 text-center border-t border-slate-800">
        <div className="max-w-4xl mx-auto px-4">
          <HeartPulse size={36} className="text-cyan-500 mx-auto animate-pulse mb-4" />
          <h4 className="font-display font-bold text-lg text-white">Full Clinical Safety Audits</h4>
          <p className="text-slate-400 text-xs mt-2 max-w-xl mx-auto leading-relaxed">
            Every consultant at {HOSPITAL_NAME} participates in monthly peer-reviewed clinical audit procedures to benchmark health recoveries and prevent surgical complications completely.
          </p>
        </div>
      </section>

    </div>
  );
}
