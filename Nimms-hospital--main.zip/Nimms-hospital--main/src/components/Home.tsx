/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Icon from './Icon';
import AppointmentForm from './AppointmentForm';
import { 
  DEPARTMENTS_DATA, 
  GALLERY_ITEMS, 
  TESTIMONIALS_DATA, 
  STATISTICS, 
  EMERGENCY_PHONE, 
  HOSPITAl_TAGLINE,
  ADDRESS
} from '../data';
import { 
  ShieldCheck, 
  Phone, 
  ArrowRight, 
  Clock, 
  ChevronLeft, 
  ChevronRight, 
  Star, 
  LayoutGrid, 
  Maximize2,
  Heart,
  Activity,
  Smile,
  AlertCircle
} from 'lucide-react';

interface HomeProps {
  onPageChange: (pageId: string) => void;
  onBookAppointment: () => void;
}

export default function Home({ onPageChange, onBookAppointment }: HomeProps) {
  // Testimonial slider state
  const [activeTestimonialIdx, setActiveTestimonialIdx] = useState(0);
  
  // Gallery Lightbox state
  const [selectedGalleryItem, setSelectedGalleryItem] = useState<any | null>(null);

  // Auto scroll testimonials
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonialIdx((prev) => (prev + 1) % TESTIMONIALS_DATA.length);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  const handlePrevTestimonial = () => {
    setActiveTestimonialIdx((prev) => (prev - 1 + TESTIMONIALS_DATA.length) % TESTIMONIALS_DATA.length);
  };

  const handleNextTestimonial = () => {
    setActiveTestimonialIdx((prev) => setActiveTestimonialIdx((prev + 1) % TESTIMONIALS_DATA.length));
  };

  // Why Choose Us list
  const highlights = [
    {
      title: "Experienced Clinicians",
      desc: "Our medical board consists of MDs and fellows from premium national healthcare institutions like AIIMS and global universities.",
      icon: "UserCheck",
      color: "bg-blue-50 text-blue-600 border-blue-100"
    },
    {
      title: "24/7 Trauma Emergency",
      desc: "Always responsive urgent action facilities backed by dual ICU platforms, multi-parameter monitoring, and ACLS trauma cars.",
      icon: "ShieldAlert",
      color: "bg-red-50 text-red-600 border-red-100"
    },
    {
      title: "Modern Clinical Facilities",
      desc: "Laminar-airflow operational theatres, advanced MRI models, private delivery suites, and serene restorative gardens.",
      icon: "Building",
      color: "bg-cyan-50 text-cyan-600 border-cyan-100"
    },
    {
      title: "Affordable Patient Billing",
      desc: "Recognized as a leading private hospital that believes high-quality treatment must be balanced with clear billing structures.",
      icon: "DollarSign",
      color: "bg-emerald-50 text-emerald-600 border-emerald-100"
    },
    {
      title: "Family Care Commitment",
      desc: "Guided by our founding philosophy 'You Are Family Here', we align our operations to ensure absolute patient health and love.",
      icon: "Heart",
      color: "bg-pink-50 text-pink-600 border-pink-100"
    },
    {
      title: "Advanced Medical Tech",
      desc: "High-Tesla resonance scanning, computerized automated diagnostics, bio-chemical testing benches, and keyhole surgeries.",
      icon: "Cpu",
      color: "bg-indigo-50 text-indigo-600 border-indigo-100"
    }
  ];

  return (
    <div className="font-sans text-slate-800 antialiased overflow-x-hidden">
      
      {/* 1. HERO SECTION */}
      <section className="relative min-h-[92vh] flex items-center justify-center pt-24 bg-slate-900 overflow-hidden">
        {/* Full-width Background Building Image with Dark Blue / Black luxury gradient overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?auto=format&fit=crop&q=80&w=1920" 
            alt="NIMMS Hospital Exterior" 
            className="w-full h-full object-cover object-center opacity-40 scale-105 animate-pulse"
            style={{ animationDuration: '10s' }}
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-slate-800/40 z-10" />
          <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent z-15" />
        </div>

        {/* Hero Content Container */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-20 w-full text-left py-12 md:py-20 flex flex-col justify-center">
          
          {/* Tagline Badge */}
          <div className="inline-flex items-center gap-2 bg-cyan-500/10 border border-cyan-400/30 px-3.5 py-1.5 rounded-full text-cyan-300 text-xs font-bold uppercase tracking-widest mb-6 animate-fade-in">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-ping"></span>
            <span>Premium Private Clinic & Child Care Centre</span>
          </div>

          {/* Slogan Display */}
          <h1 className="font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl text-white tracking-tight leading-[1.1] max-w-3xl">
            At <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-300">NIMMS</span>, <br />
            <span className="relative">
              {HOSPITAl_TAGLINE}
              <svg className="absolute left-0 -bottom-2 w-full h-2 text-cyan-500" viewBox="0 0 100 10" preserveAspectRatio="none">
                <path d="M0 5 Q 25 9, 50 5 T 100 5" fill="none" stroke="currentColor" strokeWidth="3" />
              </svg>
            </span>
          </h1>

          {/* Subtext description */}
          <p className="text-base sm:text-lg text-slate-300 mt-8 max-w-2xl leading-relaxed font-normal">
            Welcome to New Delhi's modern private medical harbor. We weave top-tier clinical intelligence, state-of-the-art diagnostic frameworks, and a compassionate healing touch to elevate your rehabilitation.
          </p>

          {/* Quick clinical indicators */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-10 max-w-4xl">
            <div className="flex items-center gap-2 bg-slate-800/50 backdrop-blur-sm px-4 py-3 rounded-xl border border-slate-700/20 shadow-sm">
              <ShieldCheck className="text-cyan-400 flex-shrink-0" size={18} />
              <div className="text-left leading-none">
                <span className="block text-[11px] font-extrabold text-slate-400 uppercase tracking-wider mb-0.5">Licensing</span>
                <span className="text-xs font-bold text-white">NABH Approved</span>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-slate-800/50 backdrop-blur-sm px-4 py-3 rounded-xl border border-slate-700/20 shadow-sm">
              <Phone className="text-red-400 flex-shrink-0 animate-bounce" size={18} />
              <div className="text-left leading-none">
                <span className="block text-[11px] font-extrabold text-slate-400 uppercase tracking-wider mb-0.5">Emergency</span>
                <span className="text-xs font-bold text-white">24/7 Quick Dispatch</span>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-slate-800/50 backdrop-blur-sm px-4 py-3 rounded-xl border border-slate-700/20 shadow-sm">
              <Activity className="text-emerald-400 flex-shrink-0" size={18} />
              <div className="text-left leading-none">
                <span className="block text-[11px] font-extrabold text-slate-400 uppercase tracking-wider mb-0.5">Facilities</span>
                <span className="text-xs font-bold text-white">Advanced Diagnostic Labs</span>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-slate-800/50 backdrop-blur-sm px-4 py-3 rounded-xl border border-slate-700/20 shadow-sm col-span-2 md:col-span-1">
              <Clock className="text-yellow-400 flex-shrink-0" size={18} />
              <div className="text-left leading-none">
                <span className="block text-[11px] font-extrabold text-slate-400 uppercase tracking-wider mb-0.5">OPD Timings</span>
                <span className="text-xs font-bold text-white">Mon-Sat: 9 AM-8 PM</span>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mt-10">
            <button
              onClick={onBookAppointment}
              id="hero-book-appointment-btn"
              className="bg-cyan-600 hover:bg-cyan-700 active:scale-95 text-white font-sans font-bold text-sm tracking-wider uppercase px-8 py-4 rounded-xl transition-all shadow-xl shadow-cyan-600/20 text-center flex items-center justify-center gap-2"
            >
              <span>Book Appointment</span>
              <ArrowRight size={16} />
            </button>
            
            <a
              href={`tel:${EMERGENCY_PHONE}`}
              className="bg-red-500/10 hover:bg-red-500/25 active:scale-95 text-red-400 font-sans font-extrabold text-sm tracking-wider uppercase px-8 py-4 rounded-xl transition-all border border-red-500/30 text-center flex items-center justify-center gap-2.5"
            >
              <Phone size={15} />
              <span>Emergency 24/7 Hotline</span>
            </a>
          </div>

        </div>
      </section>


      {/* 2. ABOUT MINI-TEASER SECTION */}
      <section className="py-20 bg-white relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Image Box (Using luxury marble reception lobby desk screenshot representation) */}
            <div className="lg:col-span-5 relative group">
              <div className="absolute -inset-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-2xl blur opacity-15" />
              <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-slate-100">
                <img 
                  src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=800" 
                  alt="NIMMS Hospital Reception Area" 
                  className="w-full h-[360px] object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/20 text-left text-white">
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-cyan-300">Admission Lobby</span>
                  <h4 className="font-display font-bold text-sm mt-0.5">Sleek Backlit Marble Terminal</h4>
                </div>
              </div>
            </div>

            {/* Content Box */}
            <div className="lg:col-span-7 text-left flex flex-col justify-center">
              <div className="flex items-center gap-2 text-cyan-600 font-bold text-xs uppercase tracking-widest mb-3">
                <span className="w-1.5 h-1.5 bg-cyan-600 rounded-full" />
                <span>Modern Legacy & Mission</span>
              </div>
              <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 leading-tight">
                Our Patient Trust Philosophy Is Grounded In Family Values.
              </h2>
              <p className="text-slate-500 mt-6 leading-relaxed">
                NIMMS Hospital was founded on a simple, yet uncompromising promise: to render world-class clinical intelligence within a comforting family sanctuary. Our patient care models dismiss institutional chill and replace it with absolute warmth, empathetic dialogue, and precision technology.
              </p>
              
              {/* Mission & Vision Subcards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8">
                <div className="p-5 rounded-xl bg-slate-50 border border-slate-100/80">
                  <div className="text-cyan-600 font-bold text-sm tracking-wide flex items-center gap-2">
                    <span className="w-2.5 h-2.5 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full" />
                    <span>Our Sacred Mission</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-2.5 leading-relaxed">
                    To deliver uncompromised clinical diagnostic accuracy, reliable healthcare plans, and empathetic healing, securing medical relief for communities across India.
                  </p>
                </div>
                <div className="p-5 rounded-xl bg-slate-50 border border-slate-100/80">
                  <div className="text-cyan-600 font-bold text-sm tracking-wide flex items-center gap-2">
                    <span className="w-2.5 h-2.5 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full" />
                    <span>Our Strategic Vision</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-2.5 leading-relaxed">
                    To define the standards of corporate healthcare environments by integrating automated patient logs, elite diagnostics, and a restorative, natural environment.
                  </p>
                </div>
              </div>

              <button
                onClick={() => onPageChange('about')}
                className="mt-8 self-start flex items-center gap-2 text-sm font-bold text-cyan-600 hover:text-cyan-700 transition-all font-sans group"
              >
                <span>Read Our Extended History</span>
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </button>
            </div>

          </div>
        </div>
      </section>


      {/* 3. WHY CHOOSE US SECTION */}
      <section className="py-20 bg-slate-50 border-y border-slate-100 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-14">
            <div className="inline-flex items-center gap-2 text-cyan-600 font-bold text-xs uppercase tracking-widest mb-3">
              <span className="w-1.5 h-1.5 bg-cyan-600 rounded-full" />
              <span>Differentiating Core Values</span>
            </div>
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 tracking-tight leading-snug">
              Why Families Standardize On NIMMS Hospital
            </h2>
            <p className="text-sm text-slate-500 mt-3 leading-relaxed">
              We stand apart as a premium clinic by guaranteeing that high clinical engineering is coupled with compassionate care, 24/7 protection, and clear-cut affordability.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {highlights.map((item, idx) => (
              <div 
                key={idx} 
                className="bg-white border border-slate-100/85 p-6 rounded-2xl hover:shadow-xl hover:shadow-slate-100 transition-all duration-300 flex flex-col text-left group"
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center border mb-5 ${item.color} group-hover:scale-110 transition-transform duration-300`}>
                  <Icon name={item.icon} size={22} />
                </div>
                <h3 className="font-display font-bold text-slate-900 text-lg group-hover:text-cyan-600 transition-colors duration-200">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-500 mt-2.5 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>

        </div>
      </section>


      {/* 4. STATISTICS COUNTER SECTION */}
      <section className="py-16 bg-slate-900 text-white relative overflow-hidden">
        {/* Background visual accents */}
        <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-cyan-500/5 blur-[100px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
            {STATISTICS.map((stat, idx) => (
              <div key={idx} className="text-center flex flex-col items-center justify-center">
                <span className="font-display font-black text-4xl sm:text-5xl lg:text-6xl text-cyan-400 tracking-tight block">
                  {stat.value}
                </span>
                <span className="text-xs sm:text-sm text-slate-350 font-sans font-medium mt-1.5 uppercase tracking-wider block">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>


      {/* 5. DEPARTMENTS MINI DIRECTORY */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-14">
            <div className="inline-flex items-center gap-2 text-cyan-600 font-bold text-xs uppercase tracking-widest mb-3">
              <span className="w-1.5 h-1.5 bg-cyan-600 rounded-full" />
              <span>Specialized Healing Centers</span>
            </div>
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 tracking-tight leading-snug">
              Key Clinical Departments
            </h2>
            <p className="text-sm text-slate-500 mt-3 leading-relaxed">
              We provide full-spectrum medical boards across pediatric health, total bone/spine orthopedics, general medicine, maternal suite care, and emergency trauma operations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {DEPARTMENTS_DATA.map((dept) => (
              <div 
                key={dept.id} 
                className="bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl hover:scale-[1.01] transition-all duration-300 flex flex-col text-left group"
              >
                <div className="h-48 overflow-hidden relative">
                  <img 
                    src={dept.image} 
                    alt={dept.name} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent" />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-2 rounded-xl text-cyan-600 shadow-md">
                    <Icon name={dept.icon} size={20} />
                  </div>
                </div>
                
                <div className="p-6 flex-grow flex flex-col">
                  <h3 className="font-display font-bold text-slate-900 text-lg leading-tight">
                    {dept.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-2.5 leading-relaxed flex-grow">
                    {dept.shortDescription}
                  </p>
                  
                  <div className="mt-5 pt-4 border-t border-slate-50 flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                      {dept.headOfDept.split(',')[0]}
                    </span>
                    <button
                      onClick={() => onPageChange('departments')}
                      className="text-cyan-600 hover:text-cyan-700 text-xs font-bold font-sans flex items-center gap-1 group/btn"
                    >
                      <span>Explore Department</span>
                      <ArrowRight size={13} className="transition-transform group-hover/btn:translate-x-1" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>


      {/* 6. FACILITIES SHOWCASE (SLIDER / PRESETS) */}
      <section className="py-20 bg-slate-50 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col md:flex-row items-start md:items-end justify-between mb-12">
            <div className="text-left max-w-2xl">
              <div className="inline-flex items-center gap-2 text-cyan-600 font-bold text-xs uppercase tracking-widest mb-3">
                <span className="w-1.5 h-1.5 bg-cyan-600 rounded-full" />
                <span>Comfort & Technology</span>
              </div>
              <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 tracking-tight leading-snug">
                Restorative Spaces & Care Rooms
              </h2>
              <p className="text-sm text-slate-500 mt-2.5 leading-relaxed">
                Clean, meticulously planned facilities designed based on environmental comfort parameters to maximize our recovery rates.
              </p>
            </div>
            
            <button
              onClick={() => onPageChange('services')}
              className="mt-4 md:mt-0 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-bold text-xs tracking-wider uppercase px-5 py-3 rounded-xl transition-all flex items-center gap-2 shadow-sm"
            >
              <span>Explore All Ancillary Services</span>
              <Maximize2 size={13} />
            </button>
          </div>

          {/* Grid Layout illustrating specific photos from screenshots */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 text-left">
            
            {/* Facility 1: Reception Desk */}
            <div className="bg-white border border-slate-100/70 rounded-2xl overflow-hidden shadow-sm group hover:shadow-lg transition-all">
              <div className="h-52 overflow-hidden relative">
                <img 
                  src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=800" 
                  alt="Marble Reception Area" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-3 left-3 bg-cyan-600 text-white text-[9px] uppercase font-bold tracking-widest px-2.5 py-1 rounded-md">
                  Reception
                </span>
              </div>
              <div className="p-5">
                <h4 className="font-display font-bold text-slate-900 text-base">Luxury Admissions Lobby</h4>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  Beautifully polished high-sheen marble flooring, teal architectural outlines, and comfortable lounges to reduce waiting stress.
                </p>
              </div>
            </div>

            {/* Facility 2: Corridor/Garden */}
            <div className="bg-white border border-slate-100/70 rounded-2xl overflow-hidden shadow-sm group hover:shadow-lg transition-all">
              <div className="h-52 overflow-hidden relative">
                <img 
                  src="https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&q=80&w=800" 
                  alt="Atrium Courtyard Walkway" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-3 left-3 bg-cyan-600 text-white text-[9px] uppercase font-bold tracking-widest px-2.5 py-1 rounded-md">
                  Garden Courtyard
                </span>
              </div>
              <div className="p-5">
                <h4 className="font-display font-bold text-slate-900 text-base">Atrium & Tropical Patio</h4>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  Lush, living palms and air-purifying foliage housed within a tiled patio deck, covered by an overhead daylight structure.
                </p>
              </div>
            </div>

            {/* Facility 3: Patients Ward Rooms */}
            <div className="bg-white border border-slate-100/70 rounded-2xl overflow-hidden shadow-sm group hover:shadow-lg transition-all">
              <div className="h-52 overflow-hidden relative">
                <img 
                  src="https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=800" 
                  alt="General Clinical Ward" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-3 left-3 bg-cyan-600 text-white text-[9px] uppercase font-bold tracking-widest px-2.5 py-1 rounded-md">
                  Patient Ward
                </span>
              </div>
              <div className="p-5">
                <h4 className="font-display font-bold text-slate-900 text-base">Sterilized General Wards</h4>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  A high-gloss white ceramic room with comfortable blue-accented clinical beds, dedicated privacy panels, and multi-channel monitoring.
                </p>
              </div>
            </div>

          </div>

        </div>
      </section>


      {/* 7. GALLERY SECTION MASONRY */}
      <section className="py-20 bg-white border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-12">
            <div className="inline-flex items-center gap-2 text-cyan-600 font-bold text-xs uppercase tracking-widest mb-3">
              <span className="w-1.5 h-1.5 bg-cyan-600 rounded-full" />
              <span>Campus Photography</span>
            </div>
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 tracking-tight leading-snug">
              NIMMS Hospital Photo Gallery
            </h2>
            <p className="text-sm text-slate-500 mt-3 leading-relaxed">
              Real high-fidelity moments showing our exterior facade, marble lobby terminals, pediatric and consulting wings, and rest spaces.
            </p>
          </div>

          {/* Masonry-Style Responsive Grid using actual context mappings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {GALLERY_ITEMS.map((item) => (
              <div 
                key={item.id}
                onClick={() => setSelectedGalleryItem(item)}
                className="group relative rounded-2xl overflow-hidden cursor-pointer bg-slate-900 shadow-sm hover:shadow-xl transition-all duration-300 h-80"
              >
                <img 
                  src={item.imageUrl} 
                  alt={item.title} 
                  className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110 group-hover:opacity-65"
                  referrerPolicy="no-referrer"
                />
                {/* Visual Glassmorphic Overlay on Hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/20 to-transparent opacity-60 group-hover:opacity-85 transition-opacity duration-300" />
                
                <div className="absolute bottom-0 left-0 right-0 p-6 text-left transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                  <span className="text-[10px] font-extrabold text-cyan-400 uppercase tracking-widest bg-cyan-950/60 border border-cyan-800/40 px-2.5 py-1 rounded-md">
                    {item.category}
                  </span>
                  <h3 className="font-display font-bold text-white text-[17px] mt-3 leading-snug">
                    {item.title}
                  </h3>
                  <p className="text-slate-350 text-xs font-normal mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
                    {item.description}
                  </p>
                </div>

                {/* Floating zoom icon */}
                <div className="absolute top-4 right-4 w-9 h-9 bg-white/20 backdrop-blur-sm border border-white/20 rounded-lg flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Maximize2 size={16} />
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>


      {/* 8. PATIENT TESTIMONIAL SLIDER */}
      <section className="py-20 bg-slate-50 relative overflow-hidden">
        {/* Background decorative rings */}
        <div className="absolute top-1/2 left-0 w-[400px] h-[400px] rounded-full border border-cyan-500/5 -translate-y-1/2 -translate-x-1/2 pointer-events-none" />
        <div className="absolute top-1/2 right-0 w-[400px] h-[400px] rounded-full border border-blue-500/5 -translate-y-1/2 translate-x-1/2 pointer-events-none" />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10 text-center">
          <div className="inline-flex items-center gap-2 text-cyan-600 font-bold text-xs uppercase tracking-widest mb-3">
            <span className="w-1.5 h-1.5 bg-cyan-600 rounded-full" />
            <span>Verified Recoveries</span>
          </div>
          <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 tracking-tight">
            Patient Stories & Reviews
          </h2>

          {/* Testimonial Active Slider Box */}
          <div className="mt-12 bg-white rounded-2xl border border-slate-100 p-8 md:p-12 shadow-xl shadow-slate-100 relative text-left">
            {/* Large Decorative Quote icon */}
            <span className="absolute top-4 right-6 font-display font-black text-slate-50 text-7xl select-none leading-none">“</span>

            <div className="flex items-center gap-1 text-amber-400 mb-5">
              {[...Array(TESTIMONIALS_DATA[activeTestimonialIdx].rating)].map((_, i) => (
                <Star key={i} size={16} fill="currentColor" />
              ))}
            </div>

            <p className="text-slate-650 text-base md:text-lg italic leading-relaxed font-normal">
              "{TESTIMONIALS_DATA[activeTestimonialIdx].text}"
            </p>

            <div className="border-t border-slate-50 pt-6 mt-8 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex items-center gap-4">
                <img 
                  src={TESTIMONIALS_DATA[activeTestimonialIdx].image} 
                  alt={TESTIMONIALS_DATA[activeTestimonialIdx].name} 
                  className="w-12 h-12 rounded-full object-cover border border-slate-150"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="font-display font-bold text-slate-950 text-sm">{TESTIMONIALS_DATA[activeTestimonialIdx].name}</h4>
                  <p className="text-[11px] text-slate-450 uppercase font-bold mt-0.5 tracking-wider">
                    {TESTIMONIALS_DATA[activeTestimonialIdx].role}
                  </p>
                </div>
              </div>
              <div className="bg-cyan-50 border border-cyan-100 rounded-xl px-4 py-2 flex flex-col text-right">
                <span className="text-[9px] uppercase font-bold text-cyan-600 tracking-widest">clinical procedure</span>
                <span className="text-xs font-semibold text-cyan-950 mt-0.5">
                  {TESTIMONIALS_DATA[activeTestimonialIdx].treatment}
                </span>
              </div>
            </div>
          </div>

          {/* Slider controls */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <button 
              onClick={handlePrevTestimonial}
              className="w-11 h-11 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 flex items-center justify-center shadow-sm hover:scale-105 active:scale-95 transition-all"
              aria-label="Previous Story"
            >
              <ChevronLeft size={20} />
            </button>
            <div className="flex items-center gap-2">
              {TESTIMONIALS_DATA.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveTestimonialIdx(idx)}
                  className={`w-2.5 h-2.5 rounded-full transition-all duration-350 ${
                    idx === activeTestimonialIdx ? 'bg-cyan-600 w-6' : 'bg-slate-300'
                  }`}
                  aria-label={`Slide ${idx + 1}`}
                />
              ))}
            </div>
            <button 
              onClick={handleNextTestimonial}
              className="w-11 h-11 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 flex items-center justify-center shadow-sm hover:scale-105 active:scale-95 transition-all"
              aria-label="Next Story"
            >
              <ChevronRight size={20} />
            </button>
          </div>

        </div>
      </section>


      {/* 9. APPOINTMENT SCHEDULER SECTION EMBED */}
      <section className="py-20 bg-white relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900 rounded-3xl overflow-hidden shadow-2xl relative border border-slate-800">
            
            {/* Background glowing effects */}
            <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-cyan-500/10 blur-[120px] pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-96 h-96 rounded-full bg-blue-500/10 blur-[120px] pointer-events-none" />

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center p-8 md:p-14">
              
              {/* Text Side */}
              <div className="lg:col-span-5 text-left text-white z-10">
                <span className="text-[11px] font-extrabold text-cyan-400 uppercase tracking-widest leading-none mb-3.5 inline-block">
                  Appointments Registry
                </span>
                <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-white tracking-tight leading-snug">
                  Schedule Your Safe Visit Today.
                </h2>
                <p className="text-sm text-slate-300 mt-5 leading-relaxed">
                  Avoid wait queues completely. Select your preferred health specialist, verify available hour slots, and generate your direct confirmation code.
                </p>

                <div className="mt-8 space-y-4">
                  <div className="flex items-start gap-3.5">
                    <div className="w-5 h-5 rounded-full bg-cyan-500/15 text-cyan-400 mt-0.5 flex items-center justify-center border border-cyan-500/20">
                      <ShieldCheck size={11} />
                    </div>
                    <div>
                      <p className="font-bold text-sm">Protected Clinical Records</p>
                      <p className="text-xs text-slate-400 mt-0.5">Under complete medical privacy act standards.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3.5">
                    <div className="w-5 h-5 rounded-full bg-cyan-500/15 text-cyan-400 mt-0.5 flex items-center justify-center border border-cyan-500/20">
                      <Clock size={11} />
                    </div>
                    <div>
                      <p className="font-bold text-sm">Zero Delayed Cancellations</p>
                      <p className="text-xs text-slate-400 mt-0.5">Immediate notifications are dispatched via automated alert SMS.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3.5">
                    <div className="w-5 h-5 rounded-full bg-cyan-500/15 text-cyan-400 mt-0.5 flex items-center justify-center border border-cyan-500/20">
                      <Smile size={11} />
                    </div>
                    <div>
                      <p className="font-bold text-sm">Empathetic Family Welcome</p>
                      <p className="text-xs text-slate-400 mt-0.5">Friendly customer managers navigate your physical lobby checking.</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-700/35 mt-10">
                  <a href={`tel:${EMERGENCY_PHONE}`} className="flex items-center justify-between group">
                    <div className="text-left">
                      <span className="block text-[10px] font-extrabold text-red-500 uppercase tracking-wider">Unplanned Emergency Dispatch</span>
                      <span className="font-mono text-sm font-black text-slate-200 mt-0.5">{EMERGENCY_PHONE}</span>
                    </div>
                    <div className="w-10 h-10 bg-red-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-red-600/20 transition-transform group-hover:scale-105 active:scale-95">
                      <Phone size={16} />
                    </div>
                  </a>
                </div>
              </div>

              {/* Form Side */}
              <div className="lg:col-span-7 z-10 w-full">
                <div className="bg-white rounded-2xl shadow-2xl p-6 md:p-8">
                  <div className="text-left mb-5">
                    <h3 className="font-display font-extrabold text-xl text-slate-900 leading-none">Instant Clinic Reservation</h3>
                    <p className="text-xs text-slate-400 mt-1.5">No login credentials required. Key in details directly.</p>
                  </div>
                  <AppointmentForm embeddedMode={true} />
                </div>
              </div>

            </div>

          </div>
        </div>
      </section>


      {/* 10. LIGHTBOX GALLERY MODAL VIEW */}
      {selectedGalleryItem && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 md:p-8 transition-all">
          <div className="bg-white rounded-3xl overflow-hidden max-w-4xl w-full flex flex-col md:flex-row shadow-2xl border border-white/10 animate-scale-up text-slate-800">
            {/* Image Canvas */}
            <div className="md:w-3/5 h-64 md:h-[420px] bg-slate-950 select-none relative">
              <img 
                src={selectedGalleryItem.imageUrl} 
                alt={selectedGalleryItem.title} 
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />
              <span className="absolute top-4 left-4 bg-slate-900/60 backdrop-blur-sm text-cyan-400 text-[10px] uppercase font-bold tracking-widest px-3 py-1.5 rounded-lg border border-cyan-500/20">
                {selectedGalleryItem.category}
              </span>
            </div>
            {/* Info Side */}
            <div className="md:w-2/5 p-6 md:p-8 flex flex-col justify-between text-left">
              <div>
                <span className="text-[11px] font-extrabold text-cyan-600 uppercase tracking-widest">NIMMS Assets Showcase</span>
                <h3 className="font-display font-black text-slate-900 text-xl mt-1 leading-snug">{selectedGalleryItem.title}</h3>
                
                <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl mt-4 text-xs text-slate-500 leading-relaxed font-normal">
                  {selectedGalleryItem.description}
                </div>

                <div className="space-y-2 mt-5">
                  <p className="text-[11px] flex justify-between">
                    <span className="text-slate-400 font-medium">Campus Location:</span>
                    <span className="font-bold text-slate-700">Block A General Desk</span>
                  </p>
                  <p className="text-[11px] flex justify-between border-t border-slate-50 pt-2">
                    <span className="text-slate-400 font-medium">Assigned Code:</span>
                    <span className="font-mono text-slate-700">{selectedGalleryItem.localPath}</span>
                  </p>
                </div>
              </div>

              <div className="pt-6 border-t border-slate-50 flex gap-3 mt-6 md:mt-0">
                <button
                  onClick={onBookAppointment}
                  className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-sans font-bold py-3 rounded-xl transition-all text-xs uppercase"
                >
                  Book Clinic
                </button>
                <button
                  onClick={() => setSelectedGalleryItem(null)}
                  className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-sans font-bold py-3 rounded-xl transition-all text-xs uppercase"
                >
                  Close Photo
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
