/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Logo from './Logo';
import { Phone, Mail, Clock, Menu, X, ArrowRight, ShieldCheck } from 'lucide-react';
import { EMERGENCY_PHONE, INFO_EMAIL } from '../data';

interface HeaderProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  onBookAppointment: () => void;
}

export default function Header({ currentPage, onPageChange, onBookAppointment }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'departments', label: 'Departments' },
    { id: 'doctors', label: 'Our Doctors' },
    { id: 'services', label: 'Services' },
    { id: 'contact', label: 'Contact Us' }
  ];

  const handleNavClick = (pageId: string) => {
    onPageChange(pageId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      {/* Top Welcome & Contact Strip */}
      <div className="bg-slate-900 text-slate-200 text-xs py-2 px-4 md:px-8 flex justify-between items-center border-b border-slate-800 relative z-50">
        <div className="flex items-center gap-6">
          <a href={`tel:${EMERGENCY_PHONE}`} className="flex items-center gap-2 hover:text-red-400 Transition-all group">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
            <span className="font-bold text-red-500">24/7 EMERGENCY:</span> 
            <span className="font-semibold group-hover:underline">{EMERGENCY_PHONE}</span>
          </a>
          <span className="hidden lg:inline text-slate-500">|</span>
          <a href={`mailto:${INFO_EMAIL}`} className="hidden lg:flex items-center gap-1.5 hover:text-cyan-400 transition-all">
            <Mail size={13} className="text-cyan-400" />
            <span>{INFO_EMAIL}</span>
          </a>
        </div>
        <div className="flex items-center gap-4 text-slate-400">
          <div className="flex items-center gap-1.5">
            <Clock size={13} className="text-cyan-400" />
            <span>OPD: 9:00 AM - 8:00 PM</span>
          </div>
          <span className="hidden sm:inline border-r border-slate-700 h-3"></span>
          <div className="hidden sm:flex items-center gap-1 text-emerald-400 text-[11px] font-bold tracking-tight bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-900/30">
            <ShieldCheck size={11} />
            <span>NABH Accredited</span>
          </div>
        </div>
      </div>

      {/* Main Glassmorphism Header */}
      <header 
        className={`fixed top-0 left-0 w-full transition-all duration-300 z-40 ${
          isScrolled 
            ? 'top-0 bg-white/90 backdrop-blur-md shadow-lg border-b border-slate-100 py-3' 
            : 'top-8 bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Logo Brand */}
          <button 
            onClick={() => handleNavClick('home')} 
            className="flex items-center text-left focus:outline-none"
            id="nav-logo-btn"
          >
            <Logo />
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-3">
            {navItems.map((item) => {
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  id={`nav-${item.id}`}
                  className={`px-3 py-2 rounded-lg font-sans font-semibold text-sm transition-all duration-200 relative ${
                    isActive 
                      ? 'text-cyan-600 bg-cyan-50/60' 
                      : 'text-slate-600 hover:text-cyan-600 hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-1 left-3 right-3 h-[2px] bg-cyan-600 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Appointment Call-To-Action Button */}
          <div className="hidden lg:flex items-center gap-4">
            <button
              onClick={onBookAppointment}
              id="header-appointment-btn"
              className="bg-cyan-600 hover:bg-cyan-700 active:scale-[0.98] transition-all text-white font-sans font-bold text-xs tracking-wider uppercase px-5 py-2.5 rounded-full shadow-md shadow-cyan-600/10 flex items-center gap-2"
            >
              Book Appointment
              <ArrowRight size={14} />
            </button>
          </div>

          {/* Mobile Hamburguer Menu Trigger */}
          <div className="flex items-center md:hidden gap-2">
            <a 
              href={`tel:${EMERGENCY_PHONE}`} 
              className="p-2.5 rounded-full bg-red-50 text-red-600 hover:bg-red-100 active:scale-95 transition-all"
              aria-label="Emergency Call"
            >
              <Phone size={18} />
            </a>
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              id="mobile-menu-toggle"
              className="p-2.5 rounded-lg text-slate-700 hover:bg-slate-100 transition-all"
              aria-label="Toggle Menu"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="md:hidden fixed inset-0 top-[110px] bg-slate-900/65 backdrop-blur-sm z-30 transition-all">
            <div className="bg-white p-5 border-b border-slate-100 flex flex-col gap-3 shadow-2xl rounded-b-2xl max-h-[80vh] overflow-y-auto">
              <div className="text-xs font-bold text-slate-400 tracking-wider uppercase pb-1 border-b border-slate-50">
                Menu Navigation
              </div>
              {navItems.map((item) => {
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    id={`mobile-nav-${item.id}`}
                    className={`w-full py-3 px-4 rounded-xl text-left font-sans font-bold text-[15px] transition-all flex items-center justify-between ${
                      isActive 
                        ? 'text-cyan-600 bg-cyan-50/70 border-l-4 border-cyan-500' 
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>{item.label}</span>
                    <ArrowRight size={16} className={`transition-transform duration-200 ${isActive ? 'translate-x-1 text-cyan-600' : 'text-slate-300'}`} />
                  </button>
                );
              })}

              <div className="pt-3 flex flex-col gap-3.5 border-t border-slate-50">
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onBookAppointment();
                  }}
                  id="mobile-appointment-btn"
                  className="w-full bg-cyan-600 text-white font-sans font-bold text-center py-3.5 rounded-xl hover:bg-cyan-700 active:scale-95 transition-all text-sm uppercase flex items-center justify-center gap-2 shadow-lg shadow-cyan-600/10"
                >
                  <Clock size={16} />
                  <span>Book Appointment Now</span>
                </button>
                
                <div className="p-3 bg-red-50/60 rounded-xl border border-red-100 flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-[11px] font-extrabold text-red-500 uppercase tracking-widest leading-none mb-1">Emergency Dispatch</span>
                    <span className="font-mono text-sm font-black text-slate-800">{EMERGENCY_PHONE}</span>
                  </div>
                  <a 
                    href={`tel:${EMERGENCY_PHONE}`}
                    className="bg-red-600 text-white p-2.5 rounded-lg active:scale-90 transition-all shadow-md shadow-red-600/10"
                  >
                    <Phone size={14} />
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
}
