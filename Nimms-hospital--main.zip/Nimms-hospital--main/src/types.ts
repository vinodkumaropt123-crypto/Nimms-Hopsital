/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Department {
  id: string;
  name: string;
  icon: string;
  shortDescription: string;
  longDescription: string;
  image: string;
  specialties: string[];
  features: string[];
  headOfDept: string;
  contactExt: string;
}

export interface Doctor {
  id: string;
  name: string;
  specialtyId: string;
  specialtyName: string;
  role: string;
  image: string;
  education: string;
  experience: string;
  rating: number;
  reviewsCount: number;
  consultationHours: string;
  about: string;
}

export interface Service {
  id: string;
  title: string;
  icon: string;
  description: string;
  detailPoints: string[];
  bannerImage: string;
}

export interface GalleryItem {
  id: string;
  category: 'building' | 'reception' | 'staff' | 'corridor' | 'ward' | 'consultation';
  title: string;
  description: string;
  imageUrl: string;
  localPath: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  text: string;
  rating: number;
  date: string;
  treatment: string;
  image: string;
}

export interface Appointment {
  name: string;
  phone: string;
  department: string;
  doctor: string;
  date: string;
  timeSlot: string;
  notes?: string;
}
