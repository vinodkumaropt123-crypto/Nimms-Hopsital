/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './components/Home';
import About from './components/About';
import Departments from './components/Departments';
import Doctors from './components/Doctors';
import Services from './components/Services';
import Contact from './components/Contact';
import AppointmentForm from './components/AppointmentForm';
import AdminPanel from './components/AdminPanel';
import { X, Calendar, MapPin, Heart, Plus } from 'lucide-react';
import { HOSPITAL_NAME, EMERGENCY_PHONE, ADDRESS } from './data';

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [isBookModalOpen, setIsBookModalOpen] = useState<boolean>(false);
  const [presetDeptId, setPresetDeptId] = useState<string>('');
  const [presetDoctorId, setPresetDoctorId] = useState<string>('');

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  // Hook up custom routing callbacks for buttons
  const triggerAppointmentModal = (deptId = '', doctorId = '') => {
    setPresetDeptId(deptId);
    setPresetDoctorId(doctorId);
    setIsBookModalOpen(true);
  };

  const handlePageChange = (pageId: string) => {
    setCurrentPage(pageId);
  };

  const renderActivePage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <Home 
            onPageChange={handlePageChange} 
            onBookAppointment={() => triggerAppointmentModal()} 
          />
        );
      case 'about':
        return (
          <About 
            onPageChange={handlePageChange}
            onBookAppointment={() => triggerAppointmentModal()} 
          />
        );
      case 'departments':
        return (
          <Departments 
            onPageChange={handlePageChange}
            onBookAppointmentWithDept={(deptId) => triggerAppointmentModal(deptId)} 
          />
        );
      case 'doctors':
        return (
          <Doctors 
            onBookAppointmentWithDoc={(docId, deptId) => triggerAppointmentModal(deptId, docId)} 
          />
        );
      case 'services':
        return (
          <Services 
            onBookAppointment={() => triggerAppointmentModal()} 
          />
        );
      case 'contact':
        return (
          <Contact />
        );
      default:
        return (
          <Home 
            onPageChange={handlePageChange} 
            onBookAppointment={() => triggerAppointmentModal()} 
          />
        );
    }
  };

  if (currentPage === 'admin') {
    return (
      <AdminPanel onBackToWebsite={() => handlePageChange('home')} />
    );
  }

  return (
    <div className="min-h-screen bg-white text-slate-800 flex flex-col font-sans select-none antialiased">
      
      {/* Visual Floating Help Widget (bottom left) */}
      <div className="fixed bottom-6 left-6 z-30 hidden md:block">
        <a 
          href={`tel:${EMERGENCY_PHONE}`}
          className="bg-red-650 hover:bg-red-700 text-white font-mono font-bold text-xs px-4.5 py-3 rounded-full shadow-2xl flex items-center gap-2.5 transition-all duration-300 hover:scale-105 active:scale-95 group border border-red-500/30"
        >
          <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping" />
          <span className="text-red-100 uppercase tracking-wide">Emergency:</span>
          <span>{EMERGENCY_PHONE}</span>
        </a>
      </div>

      {/* Persistent Quick Book Button (bottom right for easy thumb target) */}
      <div className="fixed bottom-6 right-6 z-30">
        <button
          onClick={() => triggerAppointmentModal()}
          id="persistent-book-cta"
          className="bg-cyan-600 hover:bg-cyan-700 text-white font-sans font-bold text-xs uppercase tracking-widest px-5.5 py-4 rounded-full shadow-2xl shadow-cyan-600/30 flex items-center gap-2 transition-all duration-300 hover:scale-105 active:scale-95 hover:rotate-2"
        >
          <Calendar size={15} />
          <span>Book Active Spot</span>
        </button>
      </div>

      {/* 1. Header Navigation System */}
      <Header 
        currentPage={currentPage} 
        onPageChange={handlePageChange} 
        onBookAppointment={() => triggerAppointmentModal()} 
      />

      {/* 2. Main Page Content (State Routed) */}
      <main className="flex-grow">
        {renderActivePage()}
      </main>

      {/* 3. Footer System */}
      <Footer 
        onPageChange={handlePageChange} 
        onBookAppointment={() => triggerAppointmentModal()} 
      />

      {/* 4. MODAL DETAILED SCHEDULER POPUP */}
      {isBookModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4 md:p-8 animate-fade-in">
          <div className="bg-white rounded-3xl overflow-hidden max-w-xl w-full shadow-2xl border border-slate-100 relative animate-scale-up text-slate-800">
            
            {/* Close Trigger */}
            <button
              onClick={() => setIsBookModalOpen(false)}
              id="close-booking-modal"
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-all z-10 border border-slate-200/50"
              aria-label="Close"
            >
              <X size={18} />
            </button>

            {/* Visual banner */}
            <div className="bg-slate-900 p-6 md:p-8 text-white relative text-left overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl" />
              <div className="relative z-10">
                <div className="flex items-center gap-2 text-cyan-400 mb-1.5 text-xs font-bold uppercase tracking-wider">
                  <Heart size={14} className="text-red-500 animate-pulse" />
                  <span>{HOSPITAL_NAME}</span>
                </div>
                <h3 className="font-display font-extrabold text-xl sm:text-2xl text-white">Clinic Consultation Scheduler</h3>
                <p className="text-slate-300 text-xs mt-1 font-normal">
                  No login credentials required. Secure slot immediately.
                </p>
              </div>
            </div>

            {/* Core Appointment Form */}
            <div className="p-6 md:p-8 max-h-[75vh] overflow-y-auto">
              <AppointmentForm 
                embeddedMode={true} 
                selectedDeptId={presetDeptId}
                selectedDoctorId={presetDoctorId}
                onSuccessClose={() => setIsBookModalOpen(false)}
              />
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
