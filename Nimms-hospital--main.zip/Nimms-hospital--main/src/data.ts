/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Department, Doctor, Service, GalleryItem, Testimonial } from './types';

export const HOSPITAL_NAME = "NIMMS Hospital";
export const HOSPITAl_TAGLINE = "You Are Family Here";
export const EMERGENCY_PHONE = "+91 98765 43210";
export const INFO_EMAIL = "info@nimmshospital.com";
export const APP_PHONE = "+91 11 4987 6543";
export const ADDRESS = "Thakur Anoop Singh Marg, Sector 5, Near Child Care Centre, New Delhi, Delhi 110085";

export const DEPARTMENTS_DATA: Department[] = [
  {
    id: "general-medicine",
    name: "General Medicine",
    icon: "Stethoscope",
    shortDescription: "Comprehensive healthcare and preventative medical options for adults of all ages.",
    longDescription: "Our General Medicine Department is the first point of contact for complex diagnosing, management of chronic conditions, and wellness checks. Equipped with absolute precision diagnostics, our team collaborates globally to offer unparalleled primary clinical care.",
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=800",
    specialties: ["Chronic Disease Management", "Adult Vaccinations", "Geriatric Care", "Preventative Screening", "Metabolic Disorders Control"],
    features: ["Dedicated Outpatient Wing", "Comprehensive Annual Health Checkups", "24/7 Ward Availability", "Instant Diagnostic Labs Support"],
    headOfDept: "Dr. Alok Nath, MD",
    contactExt: "Ext 201"
  },
  {
    id: "pediatrics",
    name: "Pediatrics & Child Care",
    icon: "Baby",
    shortDescription: "Specialized clinical and emotional wellness care for newborns, children, and young adolescents.",
    longDescription: "Recognized as a leading Child Care Centre, our pediatrics division offers a vibrant, friendly atmosphere to treat children with specialized medical and surgical services while ensuring they feel safe, supported, and loved.",
    image: "https://images.unsplash.com/photo-1481841580057-e2b9927a05c6?auto=format&fit=crop&q=80&w=800",
    specialties: ["Neonatal Intensive Care (NICU)", "Pediatric Cardiology", "Growth & Development Milestones Tracking", "Childhood Immunization Programs"],
    features: ["Child-friendly Consultation Rooms", "Advanced NICU System", "24/7 Pediatric Emergency Responders", "Dedicated Pediatric Play Zone"],
    headOfDept: "Dr. Meera Sen, MD, DCH",
    contactExt: "Ext 205"
  },
  {
    id: "orthopedics",
    name: "Orthopedics & Joint Care",
    icon: "Activity",
    shortDescription: "Expert treatments for bones, joints, spine, ligaments, sports injuries, and advanced surgeries.",
    longDescription: "Restore your physical mobility at NIMMS Orthopedics. From robotic-assisted joint replacement surgeries to non-invasive physiotherapy care, our bone and joint department is recognized for its high mobility recovery rate.",
    image: "https://images.unsplash.com/photo-1579684389782-64d84b5e901a?auto=format&fit=crop&q=80&w=800",
    specialties: ["Total Hip & Knee Replacements", "Sports Medicine & Arthroscopy", "Spine Surgery", "Fracture & Trauma Rehabilitation"],
    features: ["Biomechanical Gait Analysis Lab", "Dedicated Rehabilitation Gym", "Advanced Minimally Invasive Tech", "Immediate Fracture Cast Rooms"],
    headOfDept: "Dr. Vikram Malhotra, MS (Ortho)",
    contactExt: "Ext 210"
  },
  {
    id: "gynecology",
    name: "Gynecology & Obstetrics",
    icon: "Heart",
    shortDescription: "Comprehensive, private, and caring assistance for maternal health and general women wellness.",
    longDescription: "Providing warm, comfortable maternal support during pregnancy and comprehensive medical screenings for general gynecological health. At NIMMS, we honor the miracle of birth with a premium, home-like family delivery atmosphere.",
    image: "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=800",
    specialties: ["Painless Labour Deliveries", "High-Risk Pregnancy Management", "Minimal Laparoscopic Gyne Surgery", "Infertility & Counseling Center"],
    features: ["Luxury Delivery Suites (LDR)", "Lactation & Newborn Counseling Services", "4D Ultrasound Imaging", "Private Counseling Lounges"],
    headOfDept: "Dr. Ananya Sharma, MD, DGO",
    contactExt: "Ext 214"
  },
  {
    id: "surgery",
    name: "Advanced General Surgery",
    icon: "Scissors",
    shortDescription: "Minimally invasive, laparoscopic, and modern operational procedures with fast-track recovery.",
    longDescription: "Our Surgical board operates state-of-the-art theater suites utilizing modern surgical technology. We excel in laparoscopy, gastrointestinal surgery, and oncology extractions, assuring less post-surgical pain and quicker discharge.",
    image: "https://images.unsplash.com/photo-1551884170-09fb70a3a2ed?auto=format&fit=crop&q=80&w=800",
    specialties: ["Keyhole / Laparoscopic Surgeries", "Gastrointestinal Tract Surgery", "Hernia & Thyroid Specialization", "Bariatric (Weight Loss) Surgery"],
    features: ["Ultra-clean Laminar Airflow OTs", "Post-Operative Recovery Wards", "Robotic-Assisted Surgical Tools", "Laser surgery units"],
    headOfDept: "Dr. Raghav Singhal, MS, FRCS",
    contactExt: "Ext 218"
  },
  {
    id: "emergency-care",
    name: "24/7 Emergency Care",
    icon: "FlameKindling", // standard medical icons dynamically matched or replaced in component
    shortDescription: "Immediate trauma response, life-saving critical interventions, and fast-track ambulances.",
    longDescription: "A highly responsive trauma unit functioning night and day. With an adjacent critical diagnostics lab, instant CT options, and a board-certified trauma surgical squad, we prioritize life-saving procedures first without absolute delays.",
    image: "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=800",
    specialties: ["Trauma & Accident Resuscitation", "Acute Cardiac Arrest Care", "Stroke Intervention Unit", "Toxicology & Poison Emergencies"],
    features: ["Dedicated Cardiac-Monitor Triage", "In-house Mobile X-Ray & Ultrasound", "Fully Stocked ACLS Ambulances", "Immediate Access Operation Theater"],
    headOfDept: "Dr. Sanjay Rawat, MD (Emergency Medicine)",
    contactExt: "Ext 101"
  }
];

export const DOCTORS_DATA: Doctor[] = [
  {
    id: "dr-alok-nath",
    name: "Dr. Alok Nath",
    specialtyId: "general-medicine",
    specialtyName: "General Medicine",
    role: "Director & Head of Department",
    image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=500",
    education: "MD (Medicine) - AIIMS, New Delhi",
    experience: "25+ Years of Clinical Practice",
    rating: 4.9,
    reviewsCount: 312,
    consultationHours: "Mon - Sat: 09:00 AM - 01:00 PM",
    about: "Dr. Alok Nath is a distinguished medical pioneer in managing multi-system disorders and geriatric care. He is dedicated to patient-first treatment plans, combining modern guidelines with holistic disease reversal methodologies."
  },
  {
    id: "dr-meera-sen",
    name: "Dr. Meera Sen",
    specialtyId: "pediatrics",
    specialtyName: "Pediatrics & Child Care",
    role: "Senior Clinical Advisor",
    image: "https://images.unsplash.com/photo-1594824813573-246434de83fb?auto=format&fit=crop&q=80&w=500",
    education: "MD (Pediatrics) - KGMU, Lucknow | Fellowship in Neonatology (UK)",
    experience: "18+ Years in Pediatric Care",
    rating: 4.8,
    reviewsCount: 284,
    consultationHours: "Mon - Fri: 11:00 AM - 04:00 PM",
    about: "Dr. Meera specializes in critical newborn care and development milestones. Known for her cheerful, empathetic consultation style, she renders complex clinic visits entirely stress-free for little ones and their parents alike."
  },
  {
    id: "dr-vikram-malhotra",
    name: "Dr. Vikram Malhotra",
    specialtyId: "orthopedics",
    specialtyName: "Orthopedics & Joint Care",
    role: "Chief Orthopedic Architect",
    image: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=500",
    education: "MS (Ortho) - Grant Medical College, Mumbai | Joint Replacement Fellowship (Germany)",
    experience: "20+ Years in Joint & Sports Trauma",
    rating: 4.9,
    reviewsCount: 420,
    consultationHours: "Tue, Thu, Sat: 10:00 AM - 02:00 PM",
    about: "Dr. Vikram Malhotra is a pioneer in joint replacement and arthroscopic ligament reconstruction. He has successfully performed over 5,000 knee and hip arthroplasties implementing innovative minimally invasive recovery models."
  },
  {
    id: "dr-ananya-sharma",
    name: "Dr. Ananya Sharma",
    specialtyId: "gynecology",
    specialtyName: "Gynecology & Obstetrics",
    role: "Senior Obstetrics Specialist",
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=500",
    education: "MD, DGO - Madras Medical College | Fellowship in Infertility (USA)",
    experience: "16+ Years in Women's Health",
    rating: 4.9,
    reviewsCount: 395,
    consultationHours: "Mon - Fri: 02:00 PM - 06:00 PM",
    about: "Dr. Ananya is heavily admired for her gentle touch and mastery over natural, high-risk, and painless child births. She supports prospective parents through the physical, mental, and developmental aspects of the birthing journey."
  },
  {
    id: "dr-raghav-singhal",
    name: "Dr. Raghav Singhal",
    specialtyId: "surgery",
    specialtyName: "Advanced General Surgery",
    role: "Senior Gastrointestinal Surgeon",
    image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=500",
    education: "MS (Surgery), FRCS (London) | Laparoscopy Fellow (Seoul)",
    experience: "22+ Years in Laparoscopic Surgery",
    rating: 4.9,
    reviewsCount: 260,
    consultationHours: "Mon, Wed, Fri: 12:00 PM - 03:00 PM",
    about: "Dr. Raghav Singhal is a board-certified surgeon with specialized skills in advanced laparoscopic and bariatric operations. He holds multiple accolades for delivering high-precision outcome records in gastrointestinal tract care."
  },
  {
    id: "dr-sanjay-rawat",
    name: "Dr. Sanjay Rawat",
    specialtyId: "emergency-care",
    specialtyName: "Emergency Care",
    role: "Head of Emergency & Resuscitation Center",
    image: "https://images.unsplash.com/photo-1614608682850-e0d6ed316d47?auto=format&fit=crop&q=80&w=500",
    education: "MD (Emergency Medicine) - PGIMER, Chandigarh",
    experience: "14+ Years in Critical Trauma Units",
    rating: 4.8,
    reviewsCount: 512,
    consultationHours: "On-Call / 24/7 Ward Specialist",
    about: "Dr. Sanjay is standard-bearer for critical triage operations at NIMMS. His rapid decision-making and precise, evidence-based urgent action protocols ensure life-saving results in high-pressure medical environments."
  }
];

export const SERVICES_DATA: Service[] = [
  {
    id: "icu-critical-unit",
    title: "Ultra-Modern Intensive Care Unit (ICU)",
    icon: "HeartPulse",
    description: "Multi-layered highly sterilized intensive care suites configured with active multi-parameter monitors and ventilators.",
    detailPoints: [
      "Continuous 1:1 patient-to-nurse monitoring ratios",
      "Laminar flow active air purifiers with absolute particulate capture",
      "Continuous cardiac, lung, kidney dialysis and neural monitors",
      "Direct backup power grid isolation with dual backups"
    ],
    bannerImage: "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "diagnostics-labs",
    title: "High-Resolution Radiography & Lab",
    icon: "Microscope",
    description: "Advanced multi-slice CT, high-Tesla MRI scans, digital ultrasound systems, and fully computerized bio-chemistry labs.",
    detailPoints: [
      "Ultra-fast MRI scanning ensuring noise-dampened diagnostics",
      "Digital X-Ray and 4D color-Doppler ultrasounds",
      "Auto-computerized diagnostic reports delivered via secure SMS and portal",
      "Accredited by National Quality Assurance Boards"
    ],
    bannerImage: "https://images.unsplash.com/photo-1579153196614-2c712140d393?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "pharmacy-services",
    title: "24/7 Fully Stocked Hospital Pharmacy",
    icon: "PlusCircle",
    description: "On-site comprehensive pharmacy holding critical emergency drugs, chronic care medicine lists, and infant baby wellness supplies.",
    detailPoints: [
      "Temperature-regulated storage systems for insulin, vaccines, therapies",
      "Highly professional licensed pharmacists delivering meticulous counsel",
      "Digitized barcode check preventing therapeutic prescription errors",
      "Instant home delivery for general elderly care prescriptions"
    ],
    bannerImage: "https://images.unsplash.com/photo-1512438248247-f0f2a5a8b7f0?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "ambulance-acls",
    title: "Advanced Cardiac Life Support Ambulance",
    icon: "Truck",
    description: "Rapid first-response mobile ICU vehicles stocked with oxygen, monitors, and life-saving airway kits.",
    detailPoints: [
      "ACLS-certified paramedics in instant touch with the triage desk",
      "Active vehicle GPS tracking linked to trauma systems map",
      "Automated external defibrillators (AED) and transport ventilators",
      "Zero-delay emergency dispatcher line active 24 hours a day"
    ],
    bannerImage: "https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?auto=format&fit=crop&q=80&w=800"
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "g1",
    category: "building",
    title: "NIMMS Hospital Exterior",
    description: "Our corporate medical campus has a high-design blue grid curtain glass facade, structured safety columns, and a bright red emblem display representing 'YOU ARE FAMILY HERE'.",
    imageUrl: "https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?auto=format&fit=crop&q=80&w=1200", // Sleek modern glass hospital exterior
    localPath: "/assets/images/exterior.jpg"
  },
  {
    id: "g2",
    category: "reception",
    title: "Backlit Marble Reception Lobby",
    description: "The welcoming master lobby features high-gloss visual flooring, pristine marble reception terminal backdrops, and an illuminated NIMMS teal logo to deliver absolute comfort.",
    imageUrl: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=1200", // Elegant white marble hospital desk
    localPath: "/assets/images/reception.jpg"
  },
  {
    id: "g3",
    category: "staff",
    title: "Medical Administrative Desk",
    description: "Friendly and highly professional administrative supervisors wearing bright teal medical uniforms, prepared to direct patient check-ins and general help inquiries safely.",
    imageUrl: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=1200", // Hospital staff in teal uniforms
    localPath: "/assets/images/staff.jpg"
  },
  {
    id: "g4",
    category: "corridor",
    title: "Indoor Atrium & Patio Courtyard",
    description: "Restorative tiled walking avenue under a translucent glass canopy framing lush potted palm trees and tropical shrubs to offer natural daylight healing ambiance.",
    imageUrl: "https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&q=80&w=1200", // Hospital wellness garden walkway
    localPath: "/assets/images/corridor.jpg"
  },
  {
    id: "g5",
    category: "ward",
    title: "Sterilized Multi-Bed Ward Care Unit",
    description: "Our patient-friendly general ward offers bright tiles, ergonomic medical beds designed on soft support frames with adjacent partitions and clinical dividers.",
    imageUrl: "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=1200", // Modern hospital ward with clean beds
    localPath: "/assets/images/ward.jpg"
  },
  {
    id: "g6",
    category: "consultation",
    title: "Physician Consult & Evaluation Cabin",
    description: "Advanced screening rooms showcasing framed certificates and awards, supporting in-depth reviews and professional treatment plans with our lead physicians.",
    imageUrl: "https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?auto=format&fit=crop&q=80&w=1200", // Professional doctor consultation
    localPath: "/assets/images/consultation.jpg"
  }
];

export const TESTIMONIALS_DATA: Testimonial[] = [
  {
    id: "t1",
    name: "Ramanathan Iyer",
    role: "Retired Bank Manager",
    text: "At NIMMS Hospital, they really lived up to 'You Are Family Here'. The orthopedic surgery for my knee replaced years of suffering with painless strides. Dr. Vikram is truly a gem.",
    rating: 5,
    date: "June 2, 2026",
    treatment: "Total Knee Replacement",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: "t2",
    name: "Priyanka Sharma",
    role: "Product Designer",
    text: "During my high-risk delivery, the maternal staff at the LDR suite behaved with unmatched clinical competence and wonderful warmth. I recommend their child care centre to everyone.",
    rating: 5,
    date: "May 14, 2026",
    treatment: "High-Risk Ob/Gyn Delivery",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: "t3",
    name: "Anand Gupta",
    role: "Software Architect",
    text: "I was rushed to NIMMS at 2 AM after suffering sudden appendicitis. The emergency team admitted and moved me into laparoscopic surgery within 45 minutes flat. Amazing facility!",
    rating: 5,
    date: "April 29, 2026",
    treatment: "Emergency Laparoscopic Appendectomy",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: "t4",
    name: "Gurpreet Kaur",
    role: "School Principal",
    text: "My son's childhood asthma treatment under Dr. Meera has been life-changing. She handles children so beautifully. The hospital reception is organized, completely eliminating queues.",
    rating: 5,
    date: "March 18, 2026",
    treatment: "Pediatric Asthma Management",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150"
  }
];

export const STATISTICS = [
  { value: "10,000+", label: "Patients Treated Globally" },
  { value: "50+", label: "Award-Winning Medical Board" },
  { value: "24/7", label: "Active Urgent Emergency Team" },
  { value: "95%", label: "Verified Patient Satisfaction Rate" }
];
