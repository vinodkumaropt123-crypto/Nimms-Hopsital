# NIMMS Hospital Ultra-Modern Corporate Web-Portal

> Welcome to the highly responsive, senior-developer engineered web environment for **NIMMS Hospital | "You Are Family Here"**.

Designed specifically to rival leading international medical hubs like Apollo and Medanta, this portal combines sleek glassmorphism, responsive state navigation, an interactive appointment booking terminal, and custom asset layouts matching our actual photographed facilities.

---

## 🎨 Visual Identity & Photography Focus

The design utilizes a sophisticated, light-contrast clinic aesthetic designed for optimal medical trust-building:
- **Display Headings**: Rendered in **Outfit** displaying clinical titles and credential headers.
- **Body & Controls**: Configured in **Plus Jakarta Sans** for maximum eye readability and modern layout structure.
- **Color Accent Palette**: Pure clinical Whites accompanied by **Cyan-600** and **Teal** accent elements, offset with warning **Red-650** for trauma emergencies.
- **Action Elements**: Transition hover effects, animated stats counters, active sliding testimonials, and responsive touchpoints (minimum 44px on mobile screens).

---

## 📂 Project Structure

This portal is structured modularly to avoid monolithic file bloat:
- `/src/types.ts`: Holds clear, static TypeScript interfaces for clinic departments, clinicians, and schedules.
- `/src/data.ts`: Catalogs complete hospital information, custom descriptions for our photographed assets, and clinicians.
- `/src/components/Logo.tsx`: Renders the high-fidelity inline SVG emblem of NIMMS Hospital.
- `/src/components/Icon.tsx`: Dynamically resolves Lucide-react figures with falling fail-safes.
- `/src/components/Header.tsx`: Glassmorphic relative navbar possessing active indicators and a toggleable mobile drawer.
- `/src/components/Footer.tsx`: Professional corporate footer mirroring elite private-hospital index maps.
- `/src/components/AppointmentForm.tsx`: Digital scheduling engine with contact validating controls and patient receipt tokens.
- `/src/components/Home.tsx`, `About.tsx`, `Departments.tsx`, `Doctors.tsx`, `Services.tsx`, `Contact.tsx`: Modularity in site sub-panels.

---

## 🚀 GitHub Pages Deployment Guide

Since this codebase is built using the standard Vite + React TS bundler, compiling and hosting it on your free GitHub Pages account is simple and takes less than a minute.

### 1. Build Local Production Files
Run the standard compilers to bundle and optimize our application assets:
```bash
npm run build
```
This compile directive outputs a completely self-contained, highly optimized directory inside:
👉 `dist/`

### 2. Immediate Deploy Steps
You can host that output instantly on GitHub Pages using either of these two standard models:

#### Method A: Using the `gh-pages` Helper (Recommended)
1. Install the deployment assist library:
   ```bash
   npm install -D gh-pages
   ```
2. Inject a lazy helper inside your scripts block in `package.json`:
   ```json
   "scripts": {
     "predeploy": "npm run build",
     "deploy": "gh-pages -d dist"
   }
   ```
3. Deploy directly with:
   ```bash
   npm run deploy
   ```

#### Method B: Drag-and-Drop or Actions
- Alternatively, you can directly push your `dist/` directory or set your GitHub Actions block to target the compilation output from `dist/` directly onto your static page deployment settings tab.

---

## 🏨 Mapping of Your Photographic Assets
If you wish to substitute our high-definition fallback Unsplash images on your final compiled hosting repository directly, you can map your local camera files inside `/assets/images/` using these exact names:
1. **Hospital Building** (blue grid glass facade with the white signature header) ➜ `exterior.jpg` (Used in Hero & Gallery item 1)
2. **Backlit Reception Lobby Desk** (white marble finish with backlit teal backdrop) ➜ `reception.jpg` (Used in About & Gallery item 2)
3. **Primary Administration Desk** (team sitting in bright teal medical scrubs) ➜ `staff.jpg` (Used in Gallery item 3)
4. **Indoor Patio Corridor** (beautiful tile pavement displaying potted palms and clear awning structure) ➜ `corridor.jpg` (Used in Gallery item 4)
5. **Patient General Ward** (sterilized clean room containing blue support beds & privacy dividers) ➜ `ward.jpg` (Used in Services & Gallery item 5)
6. **Clinical Consultation Cabins** (doctor desks with certificates on the wall) ➜ `consultation.jpg` (Used in Doctors & Gallery item 6)
